<?php 
include 'panel/include/header-customer.php';
if (empty($_SESSION["keranjang"]) OR !isset($_SESSION["keranjang"])) {
	echo "<script>alert('Keranjang Kosong, Silahkan Belanja');</script>";
    echo "<script>location='home.php';</script>";
} 
?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=""><a href="home.php">Beranda</a></li>
			<li class="active">Keranjang</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<div class="section-title"><h3>Keranjang Belanja</h3></div>
		<div class="row">	
			<div class="col-md-12">
				<div class="order-summary clearfix table-responsive">
					<table class="table invoice-items table-bordered table-striped">
						<thead>
							<tr class="h5 text-dark">
								<th>No</th>
								<th>Produk</th>
								<th>Berat</th>
								<th>Harga</th>
								<th>Qty</th>
								<th>Sub Berat</th>
								<th>Sub Harga</th>
								<th>Pilihan</th>
							</tr>
						</thead>
						<tbody>
							<?php 
							$nomor = 1;
							$sub_berat = 0;
							$sub_harga = 0;
							foreach ($_SESSION["keranjang"] as $id_produk => $jumlah):
							$masukkan = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
							$detail = $masukkan->fetch_assoc();
							$t_berat = $detail["berat"]*$jumlah;
							$t_harga = $detail["harga_baru"]*$jumlah;
							?>
								<tr class="h5">
									<td><?php echo $id_produk+1; ?></td>
									<td><?php echo $detail["nama"]; ?></td>
									<td><?php echo $detail['berat']; ?> gram</td>
									<td>Rp. <?php echo number_format($detail['harga_baru'],0,",","."); ?></td>
									<td><?php echo $jumlah ?></td>
									<td><?php echo $t_berat; ?> gram</td>
									<td>Rp. <?php echo number_format($t_harga,0,",","."); ?></td>
									<td>
										<a href="order-kurang.php?id=<?php echo $id_produk ?>" class="btn btn-default btn-xs"><i class="fa fa-minus"></i></a>
										<a href="order-tambah.php?id=<?php echo $id_produk ?>" class="btn btn-default btn-xs"><i class="fa fa-plus"></i></a>
										<a href="order-hapus.php?id=<?php echo $id_produk ?>" class="btn btn-danger btn-xs">Kosongkan</a>
									</td>
								</tr>
							<?php 
							$nomor++;
							$sub_berat+=$t_berat;
							$sub_harga+=$t_harga;
							endforeach
							?>
						</tbody>
					</table>
				</div>
			</div>
			<div class="col-md-12">
				<div class="row">
					<div class="pull-left col-md-6">
						<a href="home.php" class="primary-btn">Belanja</a>
						<a href="checkout.php" class="main-btn">Checkout</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>