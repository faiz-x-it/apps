<header class="page-header">
	<h2>Manajemen Produk</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen Produk</span></li>
			<li><span>Daftar Produk</span></li>
			<li><span>Form Tambah Produk</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row">
	<div class="row">
		<div class="col-md-7">
			<form method="post" enctype="multipart/form-data" class="form-vertical form-bordered">
				<section class="panel">
					<header class="panel-heading">
						<h4 class="panel-title"><small><tt>Form Tambah Produk</tt></small></h4>
					</header>
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-3 control-label">Nama Produk</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="nama">
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Harga Lama</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="harga_lama">
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Harga Baru</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="harga_baru">
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Berat</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="berat">
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label">Stock</label>
							<div class="col-md-6">
								<div data-plugin-spinner data-plugin-options='{ "value":0, "step": 1, "min": 0, "max": 99999999999 }'>
									<div class="input-group">
										<div class="spinner-buttons input-group-btn">
											<button type="button" class="btn btn-default spinner-down">
												<i class="fa fa-minus"></i>
											</button>
										</div>
										<input type="text" class="spinner-input form-control" maxlength="3" readonly name="stock">
										<div class="spinner-buttons input-group-btn">
											<button type="button" class="btn btn-default spinner-up">
												<i class="fa fa-plus"></i>
											</button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Foto Produk</label>
							<div class="col-sm-9">
								<div class="fileupload fileupload-new" data-provides="fileupload">
									<div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
										<img src="assets/images/demoUpload.jpg" alt="" />
									</div>
									<div class="fileupload-preview fileupload-exists thumbnail" style="width: 200px; height: 150px;"> 
									</div>
									<div>
										<span class="btn btn-file btn-default">
											<span class="fileupload-new">
												<span class="icon"><i class="fa fa-photo"></i>
												</span>
											</span>
											<span class="fileupload-exists">
												<span class="icon"><i class="fa fa-pencil"></i>
												</span>
											</span><input type="file" name="foto">
										</span>
										<a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload"><span class="icon"><i class="fa fa-trash-o"></i></span></a>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Diskripsi</label>
							<div class="col-sm-9">
								<textarea class="form-control" name="diskripsi"></textarea>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Kategori</label>
							<div class="col-sm-9">
								<select data-plugin-selectTwo class="form-control populate" 
								name="kategori">
								<option value=" ">Pilih</option>
								<?php 
								$masukkan = $koneksi->query("SELECT * FROM kategori ");
								while($lihat01 = $masukkan->fetch_assoc()){ 
								?>
								<option value="<?php echo $lihat01["id_kategori"] ?>">
								<?php echo $lihat01['kategori'] ?>
								</option>
								<?php
								} 
								?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Sub Kategori</label>
							<div class="col-sm-9">
								<select data-plugin-selectTwo class="form-control populate" 
								name="sub_kategori">
								<option value=" ">Pilih</option>
								<?php 
								$masukkan = $koneksi->query("SELECT * FROM sub_kategori ");
								while($lihat02 = $masukkan->fetch_assoc()){ 
								?>
								<option value="<?php echo $lihat02["id_sub_kategori"] ?>">
								<?php echo $lihat02['sub_kategori'] ?>
								</option>
								<?php
								} 
								?>
								</select>
							</div>
						</div>
					</div>
					<footer class="panel-footer">
						<div class="row">
							<div class="col-sm-9">
								<button class="btn btn-success" name="simpan">Simpan</button>
								<a href="home.php?page=produk" class="btn btn-default">Cancel</a>
							</div>
						</div>
					</footer>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
					<?php
					function resizeImage($resourceType,$image_width,$image_height) {
					$resizeWidth = 155;
					$resizeHeight = 70;
					$imageLayer = imagecreatetruecolor($resizeWidth,$resizeHeight);
					imagecopyresampled($imageLayer,$resourceType,0,0,0,0,$resizeWidth,$resizeHeight,$image_width,$image_height);
					return($imageLayer);
					}

					if(isset($_POST['simpan'])) {
						$imageProcess = 0;
						if(is_array($_FILES)) {
							$fileName = $_FILES['foto']['tmp_name'];
							$sourceProperties = getimagesize($fileName);
							$resizeFileName = time();
							$uploadPath = "../produk/";
							$fileExt = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
							$uploadImageType = $sourceProperties[2];
							$sourceImageWidth = $sourceProperties[0];
							$sourceImageHeight = $sourceProperties[1];
							switch ($uploadImageType) {
								case IMAGETYPE_JPEG:
									$resourceType = imagecreatefromjpeg($fileName);
									$imageLayer = resizeImage($resourceType,$sourceImageWidth,$sourceImageHeight);
									imagejpeg($imageLayer,$uploadPath."foto_".$resizeFileName.'.'.$fileExt);
									break;
								case IMAGETYPE_GIF:
									$resourceType = imagecreatefromgif($fileName);
									$imageLayer = resizeImage($resourceType,$sourceImageWidth,$sourceImageHeight);
									imagegif($imageLayer,$uploadPath."foto_".$resizeFileName.'.'.$fileExt);
									break;
								case IMAGETYPE_PNG:
									$resourceType = imagecreatefrompng($fileName);
									$imageLayer = resizeImage($resourceType,$sourceImageWidth,$sourceImageHeight);
									imagepng($imageLayer,$uploadPath."foto_".$resizeFileName.'.'.$fileExt);
									break;
								
								default:
									$imageProcess = 0;
									break;
							}
							move_uploaded_file($file, $uploadPath. $resizeFileName. ".". $fileExt);
							$koneksi->query("INSERT INTO produk 
							(nama,harga_lama,harga_baru,berat,stock,id_kategori,id_sub_kategori,foto,diskripsi) 
							VALUES ('$_POST[nama]','$_POST[harga_lama]','$_POST[harga_baru]','$_POST[berat]',
							'$_POST[stock]','$_POST[kategori]','$_POST[sub_kategori]','$imageLayer',
							'$_POST[diskripsi]')");
							echo "<script>location='home.php?page=produk';</script>";
						}
					}
					?>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
				</section>
			</form>
		</div>
	</div>
</div>