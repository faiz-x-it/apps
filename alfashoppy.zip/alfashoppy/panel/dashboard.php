<header class="page-header">
	<h2>Dashboard</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Dashboard</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row">
	<div class="row">
		<div class="col-md-12">
			<form>
				<section class="panel">
					<header class="panel-heading">
						<h4 class="panel-title"><small><tt>Dashboard</tt></small></h4>
					</header>
					<div class="panel-body">
						<div class="row">
							<div class="col-md-3 col-xl-4">
								<section class="panel">
									<div class="panel-body bg-danger" data-toggle="tooltip" 
									data-placement="bottom" title="Total Produk">
										<div class="widget-summary widget-summary-sm">
											<div class="widget-summary-col widget-summary-col-icon">
												<div class="summary-icon bg-secondary">
													<i class="fa fa-cubes"></i>
												</div>
											</div>
											<div class="widget-summary-col">
												<div class="summary">
													<h4 class="title">Produk</h4>
													<?php 
													$jumlah_produk = mysqli_num_rows($koneksi->query("SELECT * FROM produk")); 
													?>
													<div class="info">
														<span class="text-default">Tersedia</span>
														<strong class="amount"><?php echo "$jumlah_produk"; ?></strong>
													</div>
												</div>
											</div>
										</div>
									</div>
								</section>
							</div>
							<div class="col-md-3 col-xl-4">
								<section class="panel">
									<div class="panel-body bg-success" data-toggle="tooltip" 
									data-placement="bottom" title="Total Order">
										<div class="widget-summary widget-summary-sm">
											<div class="widget-summary-col widget-summary-col-icon">
												<div class="summary-icon bg-secondary">
													<i class="fa fa-shopping-cart"></i>
												</div>
											</div>
											<div class="widget-summary-col">
												<div class="summary">
													<h4 class="title">Order Produk</h4>
													<?php 
													$order = mysqli_num_rows($koneksi->query("SELECT * FROM order_masuk")); 
													?>
													<div class="info">
														<span class="text-default">Pemesanan</span>
														<strong class="amount"><?php echo "$order"; ?></strong>
													</div>
												</div>
											</div>
										</div>
									</div>
								</section>
							</div>
							<div class="col-md-3 col-xl-4">
								<section class="panel">
									<div class="panel-body bg-primary" data-toggle="tooltip" data-placement="bottom" title="Total Pelanggan">
										<div class="widget-summary widget-summary-sm">
											<div class="widget-summary-col widget-summary-col-icon">
												<div class="summary-icon bg-secondary">
													<i class="fa fa-users"></i>
												</div>
											</div>
											<div class="widget-summary-col">
												<div class="summary">
													<h4 class="title">Customer</h4>
													<?php 
													$jumlah_customer = mysqli_num_rows($koneksi->query("SELECT * FROM customer")); 
													?>
													<div class="info">
														<strong class="amount"><?php echo "$jumlah_customer"; ?></strong>
														<span class="text-default">Orang</span>
													</div>
												</div>
											</div>
										</div>
									</div>
								</section>
							</div>
						<!-- <div class="col-md-4 col-xl-12">
							<section class="panel">
								<div class="panel-body bg-info">
									<div class="widget-summary">
										<div class="widget-summary-col widget-summary-col-icon">
											<div class="summary-icon">
												<i class="fa fa-space-shuttle"></i>
											</div>
										</div>
										<div class="widget-summary-col">
											<div class="summary">
												<div class="text-left">
													Belum Lunas :<br>
													Pending :<br>
													Barang Terkirim :
												</div>
											</div>
											<div class="summary-footer">
												<a class="text-uppercase">Jumlah :</a>
											</div>
										</div>
									</div>
								</div>
							</section>
						</div>
					<div class="col-md-4 col-xl-12">
						<section class="panel">
							<div class="panel-body bg-quartenary">
								<div class="widget-summary">
									<div class="widget-summary-col widget-summary-col-icon">
										<div class="summary-icon">
											<i class="fa fa-rss"></i>
										</div>
									</div>
									<div class="widget-summary-col">
										<div class="summary">
											<div class="text-left">
												Pengunjung Online :<br>
												Pengunjung Hari Ini :<br>
												Total Pengunjung :
											</div>
										</div>
										<div class="summary-footer">
											<a class="text-uppercase">Jumlah :</a>
										</div>
									</div>
								</div>
							</div>
						</section>
					</div>
					<div class="col-md-4 col-xl-12">
						<section class="panel">
							<div class="panel-body bg-tertiary">
								<div class="widget-summary">
									<div class="widget-summary-col widget-summary-col-icon">
										<div class="summary-icon">
											<i class="fa fa-comments-o"></i>
										</div>
									</div>
									<div class="widget-summary-col">
										<div class="summary">
											<div class="text-left">
												Komentar Pelanggan :<br>
												Iklan Toko-Ku :<br>
												Berita :
											</div>
										</div>
										<div class="summary-footer">
											<a class="text-uppercase">Jumlah :</a>
										</div>
									</div>
								</div>
							</div>
						</section>
					</div>
					<div class="col-md-6 col-xl-12">
						<section class="panel">
							<div class="panel-body bg-success">
								<div class="widget-summary">
									<div class="widget-summary-col widget-summary-col-icon">
										<div class="summary-icon">
											<i class="fa fa-money"></i>
										</div>
									</div>
									<div class="widget-summary-col">
										<div class="summary">
											<h4 class="title">Total Pendapatan</h4>
											<div class="text-left">
												( Per Bulan )<br>
												
											</div>
										</div>
										<div class="summary-footer">
											<a class="text-uppercase">Jumlah :</a>
										</div>
									</div>
								</div>
							</div>
						</section>
					</div> -->
				</div>
			</div>
		</section>
	</form>
</div>
</div>
</div>