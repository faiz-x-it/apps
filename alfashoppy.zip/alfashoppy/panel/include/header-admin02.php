<form action="" class="search nav-form">
	<div class="input-group input-search">
		<input type="text" class="form-control" name="keyword" id="pencarian" placeholder="Search...">
		<span class="input-group-btn">
			<button class="btn btn-default" type="submit"><i class="fa fa-search"></i></button>
		</span>
	</div>
</form>
<span class="separator"></span>
<ul class="notifications">
	<li><a href="" class="dropdown-toggle notification-icon" data-toggle="dropdown"><i class="fa fa-tasks"></i><span class="badge">3</span></a>
		<div class="dropdown-menu notification-menu large">
			<div class="notification-title">
				<span class="pull-right label label-default">3</span>
				Tasks
			</div>
			<div class="content">
				<ul>



				</ul>
			</div>
		</div>
	</li>
	<li>
		<a href="" class="dropdown-toggle notification-icon" data-toggle="dropdown"><i class="fa fa-envelope"></i><span class="badge">3</span></a>
		<div class="dropdown-menu notification-menu">
			<div class="notification-title">
				<span class="pull-right label label-default">230</span>
				Pesan Masuk
			</div>
			<div class="content">
				<ul>
					
					
					
				</ul>
				<hr>
				<div class="text-right"><a href="#" class="view-more">Lihat Semua</a></div>
			</div>
		</div>
	</li>
	<li><a href="" class="dropdown-toggle notification-icon" data-toggle="dropdown"><i class="fa fa-bell"></i><span class="badge">3</span></a>
		<div class="dropdown-menu notification-menu">
			<div class="notification-title">
				<span class="pull-right label label-default">3</span>
				Notifikasi
			</div>
			<div class="content">
				<ul>
					
					
				</ul>
				<hr>
				<div class="text-right"><a href="#" class="view-more">Lihat Semua</a></div>
			</div>
		</div>
	</li>
</ul>
<span class="separator"></span>
<div id="userbox" class="userbox">
	<a href="" data-toggle="dropdown">
		<figure class="profile-picture">
			<img src="assets/images/admin.jpg" alt="Administrator" class="img-square" data-lock-picture="assets/images/!logged-user.jpg" />
		</figure>
		<?php 
		$masukkan = $koneksi->query("SELECT * FROM administrator");
		$pecah = $masukkan->fetch_assoc();
		?>
		<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@okler.com">
			<span class="name"><?php echo $pecah['nama']; ?></span>
			<span class="role">Username : <?php echo $pecah['username']; ?></span>
		</div>
		<i class="fa custom-caret"></i>
	</a>	
	<div class="dropdown-menu">
		<ul class="list-unstyled">
			<li class="divider"></li>
			<li>
				<a role="menuitem" tabindex="-1" href=""><i class="fa fa-user"></i> My Profile</a>
			</li>
			<li>
				<a role="menuitem" tabindex="-1" href="" data-lock-screen="true"><i class="fa fa-lock"></i> Lock Screen</a>
			</li>
			<li>
				<a role="menuitem" tabindex="-1" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
			</li>
		</ul>
	</div>
</div>