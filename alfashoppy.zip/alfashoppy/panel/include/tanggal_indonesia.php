<?php
function tanggal_indonesia($tanggal) {
	// fungsi bulan
	$bulan = array (
	1=> 'Januari',
		'Februari',
		'Maret',
		'April',
		'Mei',
		'Juni',
		'Juli',
		'Agustus',
		'September',
		'Oktober',
		'November',
		'Desember');
	// fungsi hari
	$hari = array (
	1=> 'Senin',
		'Selasa',
		'Rabu',
		'Kamis',
		'Jumat',
		'Sabtu',
		'Minggu');

	$dor = explode('-', $tanggal);

	// variabel tampilkan 0 = tanggal
	// variabel tampilkan 1 = bulan
	// variabel tampilkan 2 = tahun

	return $hari[ (int)$dor[1] ] .', '. $dor[2] .' '. $bulan[ (int)$dor[1] ] .' '. $dor[0];	
}
?>