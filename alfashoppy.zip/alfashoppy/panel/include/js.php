<script src="assets/js/jquery-1.10.2.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/jquery.metisMenu.js"></script>
<script src="assets/js/morris/raphael-2.1.0.min.js"></script>
<script src="assets/js/morris/morris.js"></script>
<script src="assets/js/dataTables/jquery.dataTables.js"></script>
    <script src="assets/js/dataTables/dataTables.bootstrap.js"></script>
        <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
<script src="assets/js/custom.js"></script>
<!-- Untuk Halaman Pengunjung -->
<script type="text/javascript" src="panel/assets/js/bootstrap.js"></script>
<script type="text/javascript" src="panel/assets/js/jquery.js"></script>