<li><a href="home.php"><i class="fa fa-home" aria-hidden="true"></i><span> Dashboard</span></a></li>
<li><a href="home.php?page=ganti-password"><i class="fa fa-key" aria-hidden="true"></i><span> Ganti Password</span></a></li>
<li><a href="http://localhost/alfashoppy/" target="_blank"><i class="fa fa-laptop" aria-hidden="true"></i><span> Tampilkan WEB</span></a></li>
<li class="nav-parent"><a><i class="fa fa-tasks" aria-hidden="true"></i><span> Manajemen Produk</span></a>
	<ul class="nav nav-children">
		<li><a href="home.php?page=kategori"><i class="fa fa-th-large" aria-hidden="true"></i>Kategori</a>
		<li><a href="home.php?page=produk"><i class="fa fa-database" aria-hidden="true"></i>Produk</a>
		<li><a href="home.php?page=jasa-pengiriman"><i class="fa fa-send-o" aria-hidden="true"></i>Jasa Pengiriman</a>
		<li><a href="home.php?page=ongkir"><i class="fa fa-money" aria-hidden="true"></i>Ongkos Kirim</a>
	</ul>
</li>
<li class="nav-parent"><a><i class="fa fa-tasks" aria-hidden="true"></i><span> Manajemen Customer</span></a>
	<ul class="nav nav-children">
		<li><a href="home.php?page=order-masuk"><i class="fa fa-download" aria-hidden="true"></i>Order Masuk</a>
		<li><a href="home.php?page=data-customer"><i class="fa fa-paste" aria-hidden="true"></i>Data Customer</a>
	</ul>
</li>
<li class="nav-parent"><a><i class="fa fa-tasks" aria-hidden="true"></i><span> Manajemen Admin</span></a>
	<ul class="nav nav-children">
		<li><a href="home.php?page=rekening"><i class="fa fa-credit-card" aria-hidden="true"></i>Rekening</a>
		<li><a href="home.php?page=laporan"><i class="fa fa-paste" aria-hidden="true"></i>Laporan</a>
	</ul>
</li>
<li><a href="home.php?page=logout" onclick="return confirm('Anda Yakin Ingin Keluar Dari Ruang Manajemen ?');"><i class="fa fa-power-off" aria-hidden="true"></i><span>Log Out</span></a></li>