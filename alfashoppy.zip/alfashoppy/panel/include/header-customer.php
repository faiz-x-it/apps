<?php
session_start();
include 'panel/koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Alfashoppy | Toko Komputer</title>
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />
	<link type="text/css" rel="stylesheet" href="css/slick.css" />
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css" />
	<link type="text/css" rel="stylesheet" href="css/nouislider.min.css" />
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link type="text/css" rel="stylesheet" href="css/style.css" />
	<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
	<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
</head>
<body>
	<header>
		<div id="header">
			<div class="container">
				<div class="header-logo pull-left">
					<a class="logo" href="home.php">
						<img src="./img/logo-toko.png" alt="">
					</a>
				</div>
				<div class="header-search pull-right col-md-5 col-lg-10 col-xs-5 col-sm-5">
					<form action="pencarian.php" method="get">
						<input class="input search" name="kata_kunci" type="text" placeholder="Cari Produk">
						<button class="search-btn"><i class="fa fa-search"></i></button>
					</form>
					<ul class="header-btns">
						<li class="nav-toggle">
							<button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</header>
	<div id="navigation">
		<div class="container">
			<div id="responsive-nav">
				<div class="category-nav show-on-click">
					<div class="category-nav show-on-click">
						<span class="category-header"><small>Kategori</small><i class="fa fa-bars"></i></span>
							<!-- <ul class="category-list">
								<li class="dropdown side-dropdown"><a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><small>Kategori</small></a></li>
							</ul> -->
					</div>
				</div>
				<div class="menu-nav">
					<span class="menu-header">Menu <i class="fa fa-bars"></i></span>
					<ul class="menu-list">
						<li><a href="home.php"><small>Beranda</small></a></li>
						<li><a href="keranjang.php"><small>Keranjang</small></a></li>
						<li><a href="checkout.php"><small>Checkout</small></a></li>

						<?php if(isset($_SESSION["customer"])): ?>
						<li><a href="riwayat.php"><small>Riwayat</small></a></li>
						<li><a href="logout-customer.php"><small>Logout</small></a></li>
						<?php else: ?>
							
						<li><a href="login-customer.php"><small>Login</small></a></li>
						<?php endif ?>
					</ul>
				</div>
			</div>
		</div>
	</div>