<!-- ======================================================================================== -->
<!-- ======================================== Footer ======================================== -->
	<footer id="footer" class="section section-grey">
		<div class="container">
			<div class="row">
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<div class="footer-logo">
							<a class="logo" href="home.php"><img src="./img/logo-toko.png" alt=""></a>
						</div>
						<p>Alfashoppy, belanja peralatan & perlengkapan komputer dengan harga murah & berkualitas.</p>
						<ul class="footer-social">
							<li><a href="https://www.facebook.com/walidaynie/" target="_blank"><i class="fa fa-facebook"></i></a></li>
							<li><a href="https://www.instagram.com/walidaynie/" target="_blank"><i class="fa fa-instagram"></i></a></li>
							<li><a href="https://wa.me/6283845724228?text=Saya%20ingin%20bertanya" target="_blank"><i class="fa fa-whatsapp"></i></a></li>
							<li><a href=""><i class="fa fa-phone"></i></a></li>
							<li><a href=""><i class="fa fa-envelope"></i></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-2 col-sm-6 col-xs-6">
					<div class="footer">
						<h3 class="footer">Admin</h3>
						<ul class="list">
							<li><a href="info.php">Profil</a></li>
							<li><a href="info.php">Blog Alfashoppy</a></li>
							<li><a href="info.php">Tentang Alfashoppy</a></li>
							<li><a href="info.php">Pengajuan Pertanyaan</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-2 col-sm-6 col-xs-6">
					<div class="footer">
						<h3 class="footer">Customer</h3>
						<ul class="list">
							<li><a href="">Ganti Akun</a></li>
							<li><a href="login-customer.php">Login Customer</a></li>
							<li><a href="cara-belanja.php">Cara Belanja</a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-4 col-sm-6 col-xs-6">
					<div class="footer">
						<h3 class="footer">Tetap Terhubung</h3>
						<p>Diskusikan pertanyaan dan keluhan anda dengan kami lewat email.</p>
						<form>
							<div class="form-group">
								<input type="name" class="input" placeholder="Masukkan Email Anda">
							</div>
							<div class="pull-right">
								<button class="primary-btn">Gabung Sekarang</button>
							</div>
						</form>
					</div>
				</div>
			</div>
			<hr>
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center">
					<div class="footer">
						<p>Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved | Alfashoppy, Belanja Mudah, Aman dan Terpercaya <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Muhammad Itba'ul Walidaini</a></p>
					</div>
				</div>
			</div>
		</div>
	</footer>
<!-- ======================================== Footer ======================================== -->
<!-- ======================================================================================== -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>
	<script src="js/examples.modals.js"></script>
	<script src="css/bootstrap-multiselect/bootstrap-multiselect.js"></script>
</body>
</html>