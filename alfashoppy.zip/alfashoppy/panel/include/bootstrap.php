<link href="assets/css/bootstrap.css" rel="stylesheet" /> 
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" /> 
<link href="assets/css/custom.css" rel="stylesheet" />
<link href="assets/js/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<!-- Untuk Halaman Pengunjung -->
<link rel="stylesheet" type="text/css" href="panel/assets/css/bootstrap.css">