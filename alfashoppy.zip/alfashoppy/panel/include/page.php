<?php
if (isset($_GET['page'])) {
	if ($_GET['page']=="ganti-password") {
		include 'core/ganti-password/ganti-password.php';
	} elseif ($_GET['page']=="produk") {
		include 'core/produk/produk.php';
	} elseif ($_GET['page']=="tambah-produk") {
		include 'core/produk/tambah.php';
	} elseif ($_GET['page']=="edit-produk") {
		include 'core/produk/edit.php';
	} elseif ($_GET['page']=="hapus-produk") {
		include 'core/produk/hapus.php';
	} elseif ($_GET['page']=="kategori") {
		include 'core/kategori/kategori.php';
	} elseif ($_GET['page']=="tambah-kategori") {
		include 'core/kategori/tambah.php';
	} elseif ($_GET['page']=="edit-kategori") {
		include 'core/kategori/edit.php';
	} elseif ($_GET['page']=="hapus-kategori") {
		include 'core/kategori/hapus.php';
	} elseif ($_GET['page']=="jasa-pengiriman") {
		include 'core/jasa-pengiriman/jasa-pengiriman.php';
	} elseif ($_GET['page']=="tambah-jasa-pengiriman") {
		include 'core/jasa-pengiriman/tambah.php';
	} elseif ($_GET['page']=="edit-jasa-pengiriman") {
		include 'core/jasa-pengiriman/edit.php';
	} elseif ($_GET['page']=="hapus-jasa-pengiriman") {
		include 'core/jasa-pengiriman/hapus.php';
	} elseif ($_GET['page']=="ongkir") {
		include 'core/ongkir/ongkir.php';
	} elseif ($_GET['page']=="tambah-ongkir") {
		include 'core/ongkir/tambah.php';
	} elseif ($_GET['page']=="edit-ongkir") {
		include 'core/ongkir/edit.php';
	} elseif ($_GET['page']=="hapus-ongkir") {
		include 'core/ongkir/hapus.php';
	} elseif ($_GET['page']=="rekening") {
		include 'core/rekening/rekening.php';
	} elseif ($_GET['page']=="tambah-rekening") {
		include 'core/rekening/tambah.php';
	 }elseif ($_GET['page']=="edit-rekening") {
		include 'core/rekening/edit.php';
	} elseif ($_GET['page']=="hapus-rekening") {
		include 'core/rekening/hapus.php';



	} elseif ($_GET['page']=="laporan") {
		// Maka masuk ke...
		include 'core/laporan/laporan.php';

	// Selain itu, jika menuju ke halaman data-customer
	}elseif ($_GET['page']=="data-customer") {
		// Maka masuk ke...
		include 'core/data-customer/data-customer.php';

	// Selain itu, jika menuju ke halaman order-masuk
	}elseif ($_GET['page']=="order-masuk") {
		// Maka masuk ke...
		include 'core/order-masuk/order.php';

	// Selain itu, jika menuju ke halaman detail-order
	}elseif ($_GET['page']=="detail-order") {
		// Maka masuk ke...
		include 'core/order-masuk/detail.php';

	// Selain itu, jika menuju ke halaman konfirmasi
	}elseif ($_GET['page']=="konfirmasi") {
		// Maka masuk ke...
		include 'core/order-masuk/konfirmasi.php';

	// Selain itu, jika menuju ke halaman hapus-detail-order
	}elseif ($_GET['page']=="hapus-detail-order") {
		// Maka masuk ke...
		include 'core/order-masuk/hapus.php';

	// Selain itu, jika menuju ke halaman logout
	}elseif ($_GET['page']=="logout") {
		// Maka masuk ke...
		include 'logout.php';

	// Selain itu, jika menuju ke profil-admin
	}elseif ($_GET['page']=="profil-admin") {
		// Maka masuk ke...
		include 'profil-admin.php';
	}
	

// Tidak ada perintah menuju halaman tertentu
}else {
	// Maka masuk ke...
	include 'dashboard.php';
}
?>