<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<?php
$database_host = 'localhost';
$database_user = 'root';
$database_password = '';
$database_name = 'alfashoppy';
$koneksi = new mysqli($database_host,$database_user,$database_password,$database_name);
if ($koneksi->connect_error) {
	die('Gagal Terhubung ke Database : '.$koneksi->connect_error);
}
?>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->