<header class="page-header">
    <h2>Manajemen Admin</h2>
    <div class="right-wrapper pull-right">
        <ol class="breadcrumbs">
            <li><a href="home.php"><i class="fa fa-home"></i></a></li>
            <li><span>Manajemen admin</span></li>
            <li><span>Laporan</span></li>
        </ol>
        <a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
    </div>
</header>
<div class="row">
    <div class="row">
        <div class="col-md-12">
            <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
            <?php
            $semua_data = array();
            $tgl_mulai = "-";
            $tgl_akhir = "-";
            if (isset($_POST["lihat"])) {
                $tgl_mulai = $_POST["tglm"];
                $tgl_akhir = $_POST["tgla"];
                $link = $koneksi->query("SELECT * FROM order_masuk LEFT JOIN customer ON order_masuk.id_customer=customer.id_customer WHERE tanggal BETWEEN '$tgl_mulai' 
                    AND '$tgl_akhir'");
                while ($detail = $link->fetch_assoc()) {
                    $semua_data[] = $detail;
                }
            }
            ?>
            <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
            <form method="post">
                <section class="panel">
                    <header class="panel-heading">
                        <h4 class="panel-title">
                            <tt><small>
                                Laporan Pembelian dari <?php echo $tgl_mulai ?> sampai <?php echo $tgl_akhir ?>    
                            </small></tt>
                        </h4>
                    </header>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-sm-5">
                                <label>Mulai Tanggal</label>
                                <input type="date" class="form-control" name="tglm" 
                                value="<?php echo $tgl_mulai ?>">
                            </div>
                            <div class="col-sm-6">
                                <label>Sampai Tanggal</label>
                                <input type="date" class="form-control" name="tgla"
                                value="<?php echo $tgl_akhir ?>">
                            </div>
                            <div class="col-sm-1">
                                <label>&nbsp;</label><br>
                                <button class="btn btn-primary" name="lihat"><i class="fa fa-search"></i></button>
                            </div>
                        </div>
                        <br>
                        <table class="table table-bordered table-striped mb-none" id="datatable-default">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Email</th>
                                    <th>Pengorder</th> 
                                    <th>Tanggal</th>
                                    <th>Total Pembelian</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
                                <?php
                                $total = 0;
                                foreach ($semua_data as $no => $hasil): 
                                $total+=$hasil["grand_total"];
                                ?>
                                <tr>   
                                    <td><?php echo $no+1; ?></td>
                                    <td><?php echo $hasil["email_login"]; ?></td>
                                    <td><?php echo $hasil["nama_lengkap"]; ?></td>
                                    <td><?php echo $hasil["tanggal"]; ?></td>
                                    <td>Rp. <?php echo number_format($hasil['grand_total'],0,",","."); ?></td>
                                    <td><?php echo $hasil['status']; ?></td>
                                </tr>
                                <?php endforeach ?>
                                <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="4">Total</th>
                                    <th>Rp. <?php echo number_format($total,0,",","."); ?></th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>      
                    </div>
                </section>
            </form>
        </div>
    </div>
</div>