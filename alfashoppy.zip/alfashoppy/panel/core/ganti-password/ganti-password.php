<header class="page-header">
	<h2>Ganti Password</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Ganti Password Administrator</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row">
	<div class="row">
		<div class="col-md-7">
			<form method="post" enctype="multipart/form-data" class="form-vertical form-bordered">
				<section class="panel">
					<header class="panel-heading">
						<h4 class="panel-title"><small><tt>Ganti Password Administrator</tt></small></h4>
					</header>
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-3 control-label">Password Lama</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="password_lama" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Password Baru</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="password_baru" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Konfirmasi Password Baru</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="konfirmasi_password_baru" required>
							</div>
						</div>
					</div>
					<footer class="panel-footer">
						<div class="row">
							<div class="col-sm-9">
								<button class="btn btn-success" name="ganti">Update Password</button>
							</div>
						</div>
					</footer>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
					<?php
					// Jika user mengirimkan perintah ganti
					if (isset($_POST['ganti'])) {
						// Membuat variabel
						$password_lama				= md5($_POST['password_lama']);
						$password_baru 				= $_POST['password_baru'];
						$konfirmasi_password_baru	= $_POST['konfirmasi_password_baru'];
						// Memeriksa apakah saat user input password lama sesuai data dalam database
						$periksa = mysqli_query($koneksi, "SELECT * FROM administrator 
						WHERE password ='$password_lama'");
						// Jika password lama tidak sama
						if (mysqli_num_rows($periksa) == 0) {
							// Maka akan menampilkan...
							echo "<script>alert('Password lama tidak sama');</script>";
							echo "<script>location='home.php?page=ganti-password';</script>";
						// Jika sama maka
						}else {
							// Jika dalam membuat password baru dan input konfirmasinya sama
							if ($password_baru == $konfirmasi_password_baru) {
								// Jika password baru lebih dari 3 digit
								if (strlen($password_baru) >= 3) {
									// Buat password baru dengan md5
									$buat = md5($password_baru);
									// Perbarui password administrator pada database
									$perbarui = mysqli_query($koneksi, "UPDATE administrator SET password ='$buat'");
									// Jika proses memperbarui berhasil
									if ($perbarui) {
										// Maka akan menampilkan...
										echo "<script>alert('Password berhasil diperbarui, silahkan login kembali');</script>";
										echo "<meta http-equiv='refresh' content='1;url=login.php'>";
									// Jika tidak berhasil
									}else {
										// Maka akan menampilkan...
										echo "<script>alert('Gagal memperbarui password');</script>";
										echo "<script>location='home.php?page=ganti-password';</script>";
									}
									// Jika password baru kurang dari 3 digit
									}else {
										// Maka akan menampilkan...
										echo "<script>alert('Password baru minimal 3 digit');</script>";
										echo "<script>location='home.php?page=ganti-password';</script>";
									}
									// Jika konfirmasi password baru tidak sama
									}else {
										echo "<script>alert('Konfirmasi password baru salah');</script>";
										echo "<script>location='home.php?page=ganti-password';</script>";
								}
							}
						}
					?>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->		
				</section>
			</form>
		</div>
	</div>
</div>