<header class="page-header">
	<h2>Manajemen Admin</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen admin</span></li>
			<li><span>Daftar Rekening</span></li>
			<li><span>Form Tambah Rekening</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row"> 
	<div class="row">
		<div class="col-md-6">
			<?php
			$semudata = array();
			$masukkan = $koneksi->query("SELECT * FROM bank");
			while ($tampilkan = $masukkan->fetch_assoc()) {
				$semudata[] = $tampilkan;
			}
			?> 
			<form method="post" enctype="multipart/form-data" class="form-vertical form-bordered">
				<section class="panel">
					<header class="panel-heading">
						<h4 class="panel-title"><small><tt>Tambah Rekening</tt></small></h4>
					</header>
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-3 control-label">Pemilik</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="pemilik" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Bank</label>
							<div class="col-sm-9">
								<select data-plugin-selectTwo class="form-control populate" name="bank" required>
									<option value="">Pilih Bank</option>
										<?php foreach ($semudata as $key => $value): ?>
											<option value="<?php echo $value['id_bank'] ?>"><?php echo $value['nama'] ?></option>
										<?php endforeach ?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">No Rekening</label>
							<div class="col-sm-9">
								<input type="number" class="form-control" name="norek" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Cabang</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="cabang" required>
							</div>
						</div>
					</div>
					<footer class="panel-footer">
						<div class="row">
							<div class="col-sm-9">
								<a href="home.php?page=rekening" class="btn btn-default">Kembali</a>								
								<button class="btn btn-success" name="simpan">Simpan</button>
							</div>
						</div>
					</footer>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
					<?php
					if (isset($_POST['simpan'])) {
						$koneksi->query("INSERT INTO rekening_tujuan (id_bank,pemilik,no_rekening,cabang) VALUES ('$_POST[bank]','$_POST[pemilik]','$_POST[norek]',
						'$_POST[cabang]')");
						echo "<script>location='home.php?page=rekening';</script>";
					}
					?>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
				</section>
			</form>
		</div>
	</div>
</div>