<header class="page-header">
	<h2>Manajemen Admin</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen admin</span></li>
			<li><span>Daftar Rekening</span></li>
			<li><span>Form Edit Rekening</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<?php
$masukkan = $koneksi->query("SELECT * FROM rekening_tujuan WHERE id_rekening_tujuan ='$_GET[id]'");
$tampilkan = $masukkan->fetch_assoc();
$semudata = array(); 
$input = $koneksi->query("SELECT * FROM bank");
while ($tampil = $input->fetch_assoc()) {
	$semudata[] = $tampil;
}
?> 
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<div class="row">
	<div class="row">
		<div class="col-md-6">
			<form method="post" enctype="multipart/form-data" class="form-vertical form-bordered">
				<section class="panel">
					<header class="panel-heading">
						<h4 class="panel-title"><small><tt>Edit Rekening</tt></small></h4>
					</header>
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-3 control-label">Pemilik</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="pemilik" value="<?php echo $tampilkan['pemilik']; ?>" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Bank</label>
							<div class="col-sm-9">
								<select data-plugin-selectTwo class="form-control populate" name="bank">
									<option value="">Pilih Bank</option>
										<?php foreach ($semudata as $key => $value): ?>
											<option value="<?php echo $value['id_bank'] ?>"
											<?php if ($tampilkan["id_bank"]==$value["id_bank"]){ echo "selected"; } ?> >
											<?php echo $value['nama'] ?></option>
										<?php endforeach ?>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">No Rekening</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="norek" value="<?php echo $tampilkan['no_rekening']; ?>" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Cabang</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="cabang" value="<?php echo $tampilkan['cabang']; ?>" required>
							</div>
						</div>
					</div>
					<footer class="panel-footer">
						<div class="row">
							<div class="col-sm-9">
								<a href="home.php?page=rekening" class="btn btn-default">Cancel</a>
								<button class="btn btn-success" name="update">Update</button>								
							</div>
						</div>
					</footer>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
					<?php 
				    if (isset($_POST['update'])) { 
				    	$koneksi->query("UPDATE rekening_tujuan SET id_bank='$_POST[bank]',pemilik='$_POST[pemilik]',no_rekening='$_POST[norek]',cabang='$_POST[cabang]'
				    	WHERE id_rekening_tujuan ='$_GET[id]'");
				    	echo "<script>location='home.php?page=rekening';</script>";
				 	}
				    ?>
				    <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
				</section>
			</form>
		</div>
	</div>
</div>