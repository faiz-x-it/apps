<header class="page-header">
	<h2>Manajemen Admin</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen admin</span></li>
			<li><span>Daftar Rekening</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row">
	<div class="row">
    	<div class="col-md-9">
        	<section class="panel">
        		<header class="panel-heading">
        			<h4 class="panel-title"><small><tt>Daftar Rekening</tt></small></h4>
				</header>
            	<div class="panel-body">
                	<table class="table table-bordered table-striped mb-none" id="datatable-default" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
                    	<thead>
                        	<tr>
                            	<th>No</th>
                            	<th>Bank</th>
	                            <th>Pemilik</th>
	                            <th>No Rekening</th>
	                            <th>Cabang</th>
	                            <th>Opsi</th>
	                        </tr>
	                    </thead>
	                    <tbody>
	                    <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
	                    <?php
						$semudata = array();
						$masukkan = $koneksi->query("SELECT * FROM rekening_tujuan LEFT JOIN bank ON rekening_tujuan.id_bank=bank.id_bank");
						while ($tampilkan = $masukkan->fetch_assoc()) {
							$semudata[] = $tampilkan;
						}
						foreach ($semudata as $key => $value) :
						?>
	                    	<tr>	
	                    		<td><?php echo $key+1; ?></td>
	                    		<td><?php echo $value['nama']; ?></td>
	                    		<td><?php echo $value['pemilik']; ?></td>
	                    		<td><?php echo $value['no_rekening']; ?></td>
	                    		<td><?php echo $value['cabang']; ?></td>
	                    		<td>
	                    			<a href="home.php?page=edit-rekening&id=<?php echo $value['id_rekening_tujuan']; ?>" class="btn btn-xs btn-default" data-toggle="tooltip" data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
	                    			<a href="home.php?page=hapus-rekening&id=<?php echo $value['id_rekening_tujuan']; ?>" class="btn btn-xs btn-default" data-toggle="tooltip" data-placement="top" title="Hapus" onclick="return confirm('Apakah anda yakin ingin menghapus data ini ?');"><i class="fa fa-trash-o"></i></a>
	                    		</td>
	                    	</tr>
	                    <?php endforeach ?>
	                    <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
	                    </tbody>
	                </table>
	            </div>
	            <footer class="panel-footer panel-featured-primary">
	                <div class="row">
	                    <div class="col-md-12 text-left">
	                        <a href="home.php?page=tambah-rekening" class="btn btn-primary"><span class="icon"><i class="fa fa-plus"></i></span> Tambah Data</a>
	                     </div>
	                </div>
	            </footer>
        	</section>
    	</div>
	</div>
</div>