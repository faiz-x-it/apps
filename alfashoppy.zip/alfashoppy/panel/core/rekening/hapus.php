<header class="page-header">
	<h2>Manajemen Admin</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen admin</span></li>
			<li><span>Daftar Rekening</span></li>
			<li><span>Hapus Rekening</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row">
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<?php
$koneksi->query("DELETE FROM rekening_tujuan WHERE id_rekening_tujuan='$_GET[id]'");
echo "<script>location='home.php?page=rekening';</script>";
?>	
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
</div>