<header class="page-header">
	<h2>Manajemen Produk</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen Produk</span></li>
			<li><span>Daftar Tarif</span></li>
			<li><span>Hapus Tarif</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row">
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<?php
$masukkan = $koneksi->query("SELECT * FROM tarif WHERE id_tarif ='$_GET[id]'");
$tampil = $masukkan->fetch_assoc();

$koneksi->query("DELETE FROM tarif WHERE id_tarif='$_GET[id]'");
echo "<script>location='home.php?page=tarif';</script>";
?>		
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
</div>