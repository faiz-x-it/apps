<header class="page-header">
	<h2>Manajemen Produk</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen Produk</span></li>
			<li><span>Daftar Tarif</span></li>
			<li><span>Form Edit Tarif</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<?php 
$masukkan = $koneksi->query("SELECT * FROM tarif_ongkir WHERE id_tarif_ongkir='$_GET[id]'");
$tampilkan = $masukkan->fetch_assoc();
$semudata = array(); 
$input = $koneksi->query("SELECT * FROM jasa_pengiriman");
while ($tampil = $input->fetch_assoc()) {
	$semudata[] = $tampil;
}
?>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<div class="row">
	<div class="row">
		<div class="col-md-6">
			<form method="post" enctype="multipart/form-data" class="form-vertical form-bordered">
				<section class="panel">
					<header class="panel-heading">
						<h4 class="panel-title"><small><tt>Edit Ongkos Kirim</tt></small></h4>
					</header>
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-3 control-label">Nama Kurir</label>
								<div class="col-sm-9">
									<select data-plugin-selectTwo class="form-control populate" name="jasakirim">
										<option value="">Pilih Kurir</option>
											<?php foreach ($semudata as $key => $value): ?>
												<option value="<?php echo $value['id_jasa_pengiriman'] ?>"
												<?php if ($tampilkan["id_jasa_pengiriman"]==$value["id_jasa_pengiriman"]){ echo "selected"; } ?> >
												<?php echo $value['nama'] ?></option>
											<?php endforeach ?>
									</select>
								</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Tarif</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="tarif" value="<?php echo $tampilkan['tarif']; ?>" required>
							</div>
						</div>
					</div>
					<footer class="panel-footer">
						<div class="row">
							<div class="col-sm-9">
								<a href="home.php?page=ongkir" class="btn btn-default">Cancel</a>								
								<button class="btn btn-success" name="update">Update</button>
							</div>
						</div>
					</footer>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
					<?php 
				    if (isset($_POST['update'])) {
				    	$koneksi->query("UPDATE tarif_ongkir SET id_jasa_pengiriman='$_POST[jasakirim]',tarif='$_POST[tarif]' WHERE id_tarif_ongkir='$_GET[id]'");
				    	echo "<script>location='home.php?page=ongkir';</script>";
				 	}
				    ?>
				    <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
				</section>
			</form>
		</div>
	</div>
</div>