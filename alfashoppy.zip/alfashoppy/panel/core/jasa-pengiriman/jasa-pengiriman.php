<header class="page-header">
	<h2>Manajemen Produk</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen Produk</span></li>
			<li><span>Daftar Kurir</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row">
	<div class="row">
    	<div class="col-md-6">
        	<section class="panel">
        		<header class="panel-heading">
        			<h4 class="panel-title"><small><tt>Jasa Pengiriman</tt></small></h4>
				</header>
            	<div class="panel-body">
                	<table class="table table-bordered table-striped mb-none" id="datatable-default" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
                    	<thead>
                        	<tr>
                            	<th>No</th>
	                            <th>Nama</th>
	                            <th>Opsi</th>
	                        </tr>
	                    </thead>
	                    <tbody>
	                    <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
	                    <?php
	                    $semudata = array();
	                    $masukkan = $koneksi->query("SELECT * FROM jasa_pengiriman");
	                    while ($tampilkan = $masukkan->fetch_assoc()) {
	                    	$semudata[] = $tampilkan;
	                    }
	                    foreach ($semudata as $key => $value):
	                    ?>
	                    	<tr>	
	                    		<td><?php echo $key+1; ?></td>
	                    		<td><?php echo $value['nama']; ?></td>
	                    		<td>
	                    			<a href="home.php?page=edit-jasa-pengiriman&id=<?php echo $value['id_jasa_pengiriman']; ?>" class="btn btn-xs btn-default" data-toggle="tooltip"
	                    				data-placement="top" title="Edit"><i class="fa fa-pencil"></i></a>
	                    			<a href="home.php?page=hapus-jasa-pengiriman&id=<?php echo $value['id_jasa_pengiriman']; ?>" class="btn btn-xs btn-default" data-toggle="tooltip"
	                    				data-placement="top" title="Hapus" onclick="return confirm('Apakah anda yakin ingin menghapus data ini ?');"><i class="fa fa-trash-o"></i></a>
	                    		</td>
	                    	</tr>
	                   	<?php endforeach ?>
	                    <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
	                    </tbody>
	                </table>
	            </div>
	            <footer class="panel-footer panel-featured-primary">
	                <div class="row">
	                    <div class="col-md-12 text-left">
	                        <a href="home.php?page=tambah-jasa-pengiriman" class="btn btn-primary"><span class="icon"><i class="fa fa-plus"></i></span> Tambah Data</a>
	                     </div>
	                </div>
	            </footer>
        	</section>
    	</div>
	</div>
</div>