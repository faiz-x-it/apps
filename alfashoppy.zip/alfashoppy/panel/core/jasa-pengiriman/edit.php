<header class="page-header">
	<h2>Manajemen Produk</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen Produk</span></li>
			<li><span>Daftar Kurir</span></li>
			<li><span>Form Edit Kurir</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<?php 
$masukkan = $koneksi->query("SELECT * FROM jasa_pengiriman WHERE id_jasa_pengiriman = '$_GET[id]'");
$tampilkan = $masukkan->fetch_assoc();
?>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<div class="row">
	<div class="row">
		<div class="col-md-6">
			<form method="post" enctype="multipart/form-data" class="form-vertical form-bordered">
				<section class="panel">
					<header class="panel-heading">
						<h4 class="panel-title"><small><tt>Edit Jasa Pengiriman</tt></small></h4>
					</header>
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-3 control-label">Nama</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="nama" value="<?php echo $tampilkan['nama']; ?>" required>
							</div>
						</div>
					</div>
					<footer class="panel-footer">
						<div class="row">
							<div class="col-sm-9">
								<a href="home.php?page=jasa-pengiriman" class="btn btn-default">Cancel</a>
								<button class="btn btn-success" name="update">Update</button>
							</div>
						</div>
					</footer>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
					<?php 
				    if (isset($_POST['update'])) {
				    $koneksi->query("UPDATE jasa_pengiriman SET nama ='$_POST[nama]' WHERE id_jasa_pengiriman ='$_GET[id]'");
				    	echo "<script>location='home.php?page=jasa-pengiriman';</script>";
				 	}
				    ?>
				    <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
				</section>
			</form>
		</div>
	</div>
</div>