<header class="page-header">
	<h2>Manajemen Produk</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen Produk</span></li>
			<li><span>Daftar Produk</span></li>
			<li><span>Hapus Produk</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<?php
$masukkan = $koneksi->query("SELECT * FROM produk WHERE id_produk ='$_GET[id]'");
$tampilkan = $masukkan->fetch_assoc();
$foto_produk = $tampilkan['foto'];
if(file_exists("../produk/$foto_produk")) {
	unlink("../produk/$foto_produk"); }
$koneksi->query("DELETE FROM produk WHERE id_produk ='$_GET[id]'");
echo "<script>location='home.php?page=produk';</script>";
?>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
</div>