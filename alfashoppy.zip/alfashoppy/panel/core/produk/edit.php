<header class="page-header">
	<h2>Manajemen Produk</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen Produk</span></li>
			<li><span>Daftar Produk</span></li>
			<li><span>Form Edit Produk</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<?php 
$masukkan = $koneksi->query("SELECT * FROM produk WHERE id_produk = '$_GET[id]'");
$tampilkan = $masukkan->fetch_assoc();
$semudata = array(); 
$input = $koneksi->query("SELECT * FROM kategori");
while ($tampil = $input->fetch_assoc()) {
	$semudata[] = $tampil;
}
?>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<div class="row">
	<div class="row">
		<div class="col-md-6">
			<form method="post" enctype="multipart/form-data" class="form-vertical form-bordered">
				<section class="panel">
					<header class="panel-heading">
						<h4 class="panel-title"><small><tt>Edit Produk</tt></small></h4>
					</header>
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-3 control-label">Nama Produk</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="nama" value="<?php echo $tampilkan['nama'] ?>" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Kategori</label>
								<div class="col-sm-9">
									<select data-plugin-selectTwo class="form-control populate" name="kategori">
										<option value="">Pilih Kategori</option>
											<?php foreach ($semudata as $key => $value): ?>
												<option value="<?php echo $value['id_kategori'] ?>"
												<?php if ($tampilkan["id_kategori"]==$value["id_kategori"]){ echo "selected"; } ?> >
												<?php echo $value['nama_kategori'] ?></option>
											<?php endforeach ?>
									</select>
								</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Harga Lama</label>
							<div class="col-sm-9">
								<input type="number" class="form-control" name="harga_lama" value="<?php echo $tampilkan['harga_lama'] ?>" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Harga Baru</label>
							<div class="col-sm-9">
								<input type="number" class="form-control" name="harga_baru" value="<?php echo $tampilkan['harga_baru'] ?>" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Berat</label>
							<div class="col-sm-9">
								<input type="number" class="form-control" name="berat" value="<?php echo $tampilkan['berat'] ?>" required>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 control-label">Stock</label>
							<div class="col-md-6">
								<div data-plugin-spinner data-plugin-options='{ "value":0, "step": 1, "min": 0, "max": 99999999999 }'>
									<div class="input-group">
										<div class="spinner-buttons input-group-btn">
											<button type="button" class="btn btn-default spinner-down">
												<i class="fa fa-minus"></i>
											</button>
										</div>
										<input type="number" class="spinner-input form-control" maxlength="3" name="stock" value="<?php echo $tampilkan['stock'] ?>">
										<div class="spinner-buttons input-group-btn">
											<button type="button" class="btn btn-default spinner-up">
												<i class="fa fa-plus"></i>
											</button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Foto Produk</label>
							<div class="col-sm-9">
								<div class="fileupload fileupload-new" data-provides="fileupload">
									<div class="fileupload-new thumbnail" style="width: 200px; height: 150px;">
										<img src="../produk/<?php echo $tampilkan['foto']; ?>">
									</div>
									<div class="fileupload-preview fileupload-exists thumbnail" style="width: 200px; height: 150px;"> 
									</div>
									<div>
										<span class="btn btn-file btn-default">
											<span class="fileupload-new">
												<span class="icon"><i class="fa fa-photo"></i>
												</span>
											</span>
											<span class="fileupload-exists">
												<span class="icon"><i class="fa fa-pencil"></i>
												</span>
											</span><input type="file" name="foto">
										</span>
										<a href="#" class="btn btn-danger fileupload-exists" data-dismiss="fileupload"><span class="icon"><i class="fa fa-trash-o"></i></span></a>
									</div>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Deskripsi</label>
							<div class="col-sm-9">
								<textarea class="form-control" name="diskripsi"><?php echo $tampilkan['deskripsi_produk']; ?></textarea>
							</div>
						</div>
					</div>
					<footer class="panel-footer">
						<div class="row">
							<div class="col-sm-9">
								<a href="home.php?page=produk" class="btn btn-default">Cancel</a>
								<button class="btn btn-success" name="update">Update</button>
							</div>
						</div>
					</footer>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
					<?php
					if (isset($_POST['update'])) {
						$foto_produk = $_FILES['foto']['name'];
						$tempat_menyimpan = $_FILES['foto']['tmp_name'];
						if (!empty($tempat_menyimpan)) {        
							$masukkan = $koneksi->query("SELECT * FROM produk WHERE id_produk='$_GET[id]'");
							$nama_foto = mysqli_fetch_array($masukkan);
							$tempat = $nama_foto['foto'];
							$hapus_foto = "../produk/$tempat";
							unlink($hapus_foto);
							move_uploaded_file($tempat_menyimpan, "../produk/$foto_produk");

							$koneksi->query("UPDATE produk SET nama='$_POST[nama]',id_kategori='$_POST[kategori]',harga_lama='$_POST[harga_lama]',harga_baru='$_POST[harga_baru]',
							berat='$_POST[berat]',stock='$_POST[stock]',foto='$foto_produk',deskripsi_produk='$_POST[diskripsi]' WHERE id_produk='$_GET[id]'");
						} else {
							$koneksi->query("UPDATE produk SET nama='$_POST[nama]',id_kategori='$_POST[kategori]',harga_lama='$_POST[harga_lama]',harga_baru='$_POST[harga_baru]',
							berat='$_POST[berat]',stock='$_POST[stock]',deskripsi_produk='$_POST[diskripsi]' WHERE id_produk='$_GET[id]'");
						}
							echo "<script>location='home.php?page=produk';</script>";
					}
					?>
					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
				</section>
			</form>
		</div>
	</div>
</div>