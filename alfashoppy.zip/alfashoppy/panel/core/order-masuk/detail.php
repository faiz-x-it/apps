<?php
$masukkan = $koneksi->query("SELECT * FROM order_masuk LEFT JOIN customer ON order_masuk.id_customer=customer.id_customer WHERE order_masuk.id_order='$_GET[id]'");
$tampil = $masukkan->fetch_assoc();
?>
<header class="page-header">
    <h2>Manajemen Cutomer</h2>
    <div class="right-wrapper pull-right">
        <ol class="breadcrumbs">
            <li><a href="home.php"><i class="fa fa-home"></i></a></li>
            <li><span>Manajemen Customer</span></li>
            <li><span>Order Masuk</span></li>
            <li><span>Detail Order</span></li>
        </ol>
        <a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
    </div>
</header>
<div class="row">
    <form method="post">
        <section class="panel">
            <div class="panel-body">
                <div class="invoice">
                    <div class="row">
                        <div class="col-xs-12 invoice-header">
                            <h4>Rincian Pembelian</h4>     
                        </div>
                    </div>
                    <div class="order-summary clearfix table-responsive">
                        <table class="table invoice-items table-striped">
                            <thead>
                                <tr>
                                    <th width="70">No</th>
                                    <th width="230">Produk</th>
                                    <th>Harga</th>
                                    <th>Berat</th>
                                    <th>Jumlah</th>
                                    <th>Sub Berat</th>
                                    <th>Sub Harga</th>
                                </tr>
                            </thead>
                            <tbody>
                            <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
                            <?php
                            $semudata = array();
                            $masukkan = $koneksi->query("SELECT * FROM detail_order LEFT JOIN produk ON detail_order.id_produk=produk.id_produk 
                            WHERE id_order ='$_GET[id]'");
                            while ($tampilkan = $masukkan->fetch_assoc()) {
                                $semudata[] = $tampilkan;
                            }
                            foreach ($semudata as $key => $value) :
                            ?>
                                <tr>
                                    <td><?php echo $key+1; ?></td>
                                    <td><?php echo $value['nama']; ?></td>
                                    <td>Rp. <?php echo number_format($value['harga_baru'],0,",","."); ?></td>
                                    <td><?php echo $value['berat']; ?> gr</td>
                                    <td><?php echo $value['qty']; ?></td>
                                    <td><?php echo $value['total_berat']; ?> gr</td>
                                    <td>Rp. <?php echo number_format($value['total_harga'],0,",","."); ?></td>
                                </tr>
                            <?php endforeach ?>
                            <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
                            </tbody>
                        </table>
                    </div>
                    <br>        
                    <div class="row">
                        <div class="col-xs-7">
                            <h4>Detail Customer</h4>

                            Kode Pembelian : SPFY-3X00<?php echo $tampil['id_order']; ?><br>
                            Tanggal :</b> <?php echo $tampil['tanggal']; ?><br>
                            Nama : <?php echo $tampil['nama_lengkap']; ?><br>
                            Email : <?php echo $tampil['email_login']; ?><br>
                            Alamat : <?php echo $tampil['alamat']; ?><br>
                            No Telepon : <?php echo $tampil['no_telepon']; ?>
                        </div>
                        <div class="col-xs-5">
                            <h4>Rincian Pembayaran</h4> 
                            <div class="table-responsive">
                                <table class="table invoice-items table-striped">
                                    <tbody>
                                        <tr>
                                            <th>Sub Total</th>
                                            <td>Rp. <?php echo number_format($tampil['sub_total'],0,",","."); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Tarif Ongkir</th>
                                            <?php
                                            $masukkan = $koneksi->query("SELECT * FROM order_masuk LEFT JOIN tarif_ongkir 
                                            ON order_masuk.id_tarif_ongkir=tarif_ongkir.id_tarif_ongkir");
                                            while ($okr = $masukkan->fetch_assoc()) { 
                                            ?>
                                            <td>Rp. <?php echo number_format($okr['tarif'],0,",","."); ?></td>
                                            <?php } ?>
                                        </tr>
                                        <tr>
                                            <th>Total Belanja</th>
                                            <td>Rp. <?php echo number_format($tampil['grand_total'],0,",","."); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-xs-7">
                        <br>
                        <a href="home.php?page=order-masuk" class="btn btn-default">Kembali</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </form>
</div>
