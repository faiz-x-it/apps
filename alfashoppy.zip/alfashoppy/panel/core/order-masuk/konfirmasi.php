<header class="page-header">
    <h2>Manajemen Cutomer</h2>
    <div class="right-wrapper pull-right">
        <ol class="breadcrumbs">
            <li><a href="home.php"><i class="fa fa-home"></i></a></li>
            <li><span>Manajemen Customer</span></li>
            <li><span>Order Masuk</span></li>
            <li><span>Konfirmasi</span></li>
        </ol>
        <a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
    </div>
</header>
<?php
$id_order = $_GET['id'];
$masukkan = $koneksi->query("SELECT * FROM order_masuk WHERE id_order ='$id_order'");
$tampil = $masukkan->fetch_assoc();
?>
<div class="row">
	<div class="row">
		<div class="col-md-6">
			<form method="post" enctype="multipart/form-data" class="form-vertical form-bordered">
				<section class="panel">
					<header class="panel-heading">
						<h4 class="panel-title"><small><tt>Konfirmasi Pembayaran</tt></small></h4>
					</header>
					<div class="panel-body">
						<div class="form-group">
							<label class="col-sm-3 control-label">Status Pengiriman</label>
							<div class="col-sm-9">
								<select data-plugin-selectTwo class="form-control populate" name="status" required>
									<option value="<?php echo $tampil['id_order'] ?>"><?php echo $tampil['status'] ?></option>
									<option value="Barang Dikemas">Barang Dikemas</option>
									<option value="Barang Sedang Dikirim">Barang Sedang Dikirim</option>
									<option value="Barang Sudah Sampai">Barang Sudah Sampai</option>
									<option value="Pengiriman Ditunda">Pengiriman Ditunda</option>
								</select>
							</div>
						</div>
						<div class="form-group">
							<label class="col-sm-3 control-label">Resi Pengiriman</label>
							<div class="col-sm-9">
								<input type="text" class="form-control" name="resi" placeholder="Kode Resi" value="<?php echo $tampil['kode_resi'] ?>" maxlength="15" required>
							</div>
						</div>
					</div>
					<footer class="panel-footer">
						<div class="row">
							<div class="col-sm-9">
								<button class="btn btn-primary" name="proses"><i class="fa fa-refresh"></i> Proses</button>
								<a href="home.php?page=order-masuk" class="btn btn-default">Kembali</a>
							</div>
						</div>
					</footer>
				</section>
			</form>
			<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
			<?php
			if (isset($_POST["proses"])) {
				$status = $_POST["status"];
				$resi = $_POST["resi"];
				$koneksi->query("UPDATE order_masuk SET status='$status',kode_resi='$resi' WHERE id_order ='$id_order'");
				echo "<script>location='home.php?page=order-masuk';</script>";
			}
			?>
			<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
		</div>
	</div>
</div>