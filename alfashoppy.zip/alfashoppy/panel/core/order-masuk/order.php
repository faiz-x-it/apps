<header class="page-header">
	<h2>Manajemen Cutomer</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen Customer</span></li>
			<li><span>Order Masuk</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row">
	<div class="row">
		<div class="col-md-10">
        	<section class="panel">
        		<header class="panel-heading">
        			<h4 class="panel-title"><small><tt>Order Customer</tt></small></h4>
				</header>
            	<div class="panel-body">
                	<table class="table table-bordered table-striped mb-none" id="datatable-default" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
                    	<thead>
                        	<tr>
                        		<th>No</th>
                        		<th>Nama</th>
                        		<th>Tanggal Order</th>
                        		<th>Status</th>
                        		<th>Keterangan</th>
	                        </tr>
	                    </thead>
	                    <tbody>
	                    <!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
	                    <?php
	                    $no = 1;
	                    $masukkan = $koneksi->query("SELECT * FROM order_masuk LEFT JOIN customer ON order_masuk.id_customer=customer.id_customer");
	                    while ($tampilkan = $masukkan->fetch_assoc()) {
	                    ?>
	                    	<tr>	
	                    		<td><?php echo $no; ?></td>
								<td><?php echo $tampilkan['nama_lengkap']; ?></td>
								<td><?php echo $tampilkan['tanggal']; ?></td>

								<?php if ($tampilkan['status']=="Pending"): ?>
								<td><a class="btn btn-warning btn-xs"><?php echo $tampilkan['status']; ?></a></td>
								<?php endif ?>
								<?php if ($tampilkan['status']=="Sudah Membayar"): ?>
								<td><a class="btn btn-success btn-xs"><?php echo $tampilkan['status']; ?></a></td>
								<?php endif ?>
								<?php if ($tampilkan['status']=="Barang Dikemas"): ?>
								<td><a class="btn btn-success btn-xs"><?php echo $tampilkan['status']; ?></a></td>
								<?php endif ?>
								<?php if ($tampilkan['status']=="Barang Sedang Dikirim"): ?>
								<td><a class="btn btn-success btn-xs"><?php echo $tampilkan['status']; ?></a></td>
								<?php endif ?>
								<?php if ($tampilkan['status']=="Barang Sudah Sampai"): ?>
								<td><a class="btn btn-success btn-xs"><?php echo $tampilkan['status']; ?></a></td>
								<?php endif ?>
								<?php if ($tampilkan['status']=="Pengiriman Ditunda"): ?>
								<td><a class="btn btn-danger btn-xs"><?php echo $tampilkan['status']; ?></a></td>
								<?php endif ?>

								<td><a href="home.php?page=detail-order&id=<?php echo $tampilkan["id_order"] ?>" class="btn btn-info btn-xs">Detail</i></a>

                            	<?php if ($tampilkan['status']=="Sudah Membayar"): ?>
			                	| <a href="home.php?page=konfirmasi&id=<?php echo $tampilkan['id_order'] ?>" class="btn btn-primary btn-xs">Konfirmasi</a>
			                	<?php endif ?>
			                	<?php if ($tampilkan['status']=="Barang Dikemas"): ?>
			                	| <a href="home.php?page=konfirmasi&id=<?php echo $tampilkan['id_order'] ?>" class="btn btn-primary btn-xs">Konfirmasi</a>
			                	<?php endif ?>
			                	<?php if ($tampilkan['status']=="Barang Sedang Dikirim"): ?>
			                	| <a href="home.php?page=konfirmasi&id=<?php echo $tampilkan['id_order'] ?>" class="btn btn-primary btn-xs">Konfirmasi</a>
			                	<?php endif ?>
			                	<?php if ($tampilkan['status']=="Barang Sudah Sampai"): ?>
			                	| <a href="home.php?page=konfirmasi&id=<?php echo $tampilkan['id_order'] ?>" class="btn btn-primary btn-xs">Konfirmasi</a>
			                	<?php endif ?>
			                	<?php if ($tampilkan['status']=="Pengiriman Ditunda"): ?>
			                	| <a href="home.php?page=konfirmasi&id=<?php echo $tampilkan['id_order'] ?>" class="btn btn-primary btn-xs">Konfirmasi</a>
			                	<?php endif ?>
								</td>
	                    	</tr>
	                    <?php 
						$no++;
        				} 
        				?>
        				<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
	                    </tbody>
	                </table>
	            </div>
        	</section>
    	</div>
	</div>
</div>
