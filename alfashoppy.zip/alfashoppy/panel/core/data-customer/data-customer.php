<header class="page-header">
	<h2>Manajemen Cutomer</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Data Customer</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row">
	<div class="row">
		<div class="col-md-9">
			<section class="panel">
				<header class="panel-heading">
					<h4 class="panel-title"><small><tt>Daftar Customer</tt></small></h4>
				</header>
				<div class="panel-body">
					<table class="table table-bordered table-striped mb-none" id="datatable-default" data-swf-path="assets/vendor/jquery-datatables/extras/TableTools/swf/copy_csv_xls_pdf.swf">
						<thead>
							<tr>
								<th>No</th>
								<th>Nama Lengkap</th>
								<th>Alamat</th>
								<th>No Telepon</th>
								<th>Email</th>
							</tr>
						</thead>
						<tbody>
						<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
	                    <?php
						$semudata = array();
						$masukkan = $koneksi->query("SELECT * FROM customer");
						while ($tampilkan = $masukkan->fetch_assoc()) {
							$semudata[] = $tampilkan;
						}
						foreach ($semudata as $key => $value) :
						?>
	                    	<tr>	
	                    		<td><?php echo $key+1 ?></td>
								<td><?php echo $value['nama_lengkap']; ?></td>
								<td><?php echo $value['alamat_customer']; ?></td>
								<td><?php echo $value['no_telepon']; ?></td>
								<td><?php echo $value['email_login']; ?></td>
	                    	</tr>
	                    <?php endforeach ?>
        				<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
	                    </tbody>
	                </table>
	            </div>
        	</section>
    	</div>
	</div>
</div>