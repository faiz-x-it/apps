<header class="page-header">
	<h2>Manajemen Produk</h2>
	<div class="right-wrapper pull-right">
		<ol class="breadcrumbs">
			<li><a href="home.php"><i class="fa fa-home"></i></a></li>
			<li><span>Manajemen Produk</span></li>
			<li><span>Daftar Kategori</span></li>
			<li><span>Hapus Kategori</span></li>
		</ol>
		<a class="sidebar-right-toggle"><i class="fa fa-chevron-left"></i></a>
	</div>
</header>
<div class="row">
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
<?php
$koneksi->query("DELETE FROM kategori WHERE id_kategori ='$_GET[id]'");
echo "<script>location='home.php?page=kategori';</script>";
?>
<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
</div>