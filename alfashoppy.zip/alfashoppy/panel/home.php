<?php
session_start();
include 'koneksi.php';
if (!isset($_SESSION['administrator'])) {
    echo "<script>location='login-admin.php';</script>";
    header('location:login-admin.php');
    exit();
}
?>
			<?php
			include 'include/header-admin01.php';
			include 'include/header-admin02.php'; 
			?>
				</div>
			</header>
			<div class="inner-wrapper">
				<aside id="sidebar-left" class="sidebar-left">
					<div class="sidebar-header">
						<div class="sidebar-toggle hidden-xs" data-toggle-class="sidebar-left-collapsed" data-target="html" data-fire-event="sidebar-left-toggle"><i class="fa fa-bars" aria-label="Toggle sidebar"></i>
						</div>
					</div>			
					<div class="nano">
						<div class="nano-content">
							<nav id="menu" class="nav-main" role="navigation">
								<ul class="nav nav-main">
								<?php include 'include/sidebar.php'; ?>
								</ul>
							</nav>
						</div>
					</div>
				</aside>
				<section role="main" class="content-body">
				<?php include 'include/page.php'; ?>
				</section>
			</div>	
		</section>
		<?php include 'include/jquery-admin.php'; ?>
	</body>
</html>