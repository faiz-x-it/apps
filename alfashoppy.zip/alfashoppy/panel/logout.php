<?php
session_destroy();
echo "<script>location='login-admin.php';</script>";
?>