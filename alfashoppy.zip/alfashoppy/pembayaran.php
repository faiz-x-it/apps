<?php 
include 'panel/include/header-customer.php';
$masukkan = $koneksi->query("SELECT * FROM order_masuk LEFT JOIN customer ON order_masuk.id_customer=customer.id_customer WHERE order_masuk.id_order='$_GET[id]'");
$detail = $masukkan->fetch_assoc();
$id_customer = $detail["id_customer"];
$id_customer_login = $_SESSION["customer"]["id_customer"];
if ($id_customer!==$id_customer_login) {
	echo "<script>location='riwayat.php';</script>";
	exit();
}
?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=""><a href="home.php">Beranda</a></li>
			<li class=""><a href="riwayat.php">Riwayat</a></li>
			<li class="active">Pembayaran</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<div class="section-title"><h3>Pembayaran</h3></div>
			<div class="row">
				<div class="col-md-12">
					<form id="checkout-form" class="clearfix" method="post">
						<div class="alert alert-info"><b>Total Tagihan Anda :</b> Rp. <?php echo number_format($detail['grand_total'],0,",","."); ?></div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<input type="text" class="input" value="<?php echo $_SESSION["customer"]['nama_lengkap']?>" readonly>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<input type="number" class="input" name="norek" placeholder="No Rekening" required>
								</div>
							</div>
						</div>
						<div class="row">
							<div class="col-md-6">
								<div class="form-group">
									<select class="input" name="bank" required>
										<option value="">Pilih Bank</option>
										<?php
										$masukkan = $koneksi->query("SELECT * FROM bank");
										while ($per = $masukkan->fetch_assoc()) { 
										?>
										<option value="<?php echo $per["id_bank"] ?>"><?php echo $per['nama'] ?>
										</option>
										<?php 
										}
										?>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<select class="input" name="rekening_tujuan" required>
										<option value="">Rekening Tujuan</option>
										<?php
										$masukkan = $koneksi->query("SELECT * FROM rekening_tujuan LEFT JOIN bank 
										ON rekening_tujuan.id_bank=bank.id_bank");
										while ($rek = $masukkan->fetch_assoc()) { 
										?>
										<option value="<?php echo $rek["id_rekening_tujuan"] ?>"><?php echo $rek['nama'] ?> (<?php echo $rek['no_rekening'] ?>) <?php echo $rek['pemilik']; ?>
										</option>
										<?php 
										}
										?>
									</select>
								</div>
							</div>
						</div>
						<div class=""><h3></h3></div>
						<div class="text-left">
							<button class="main-btn" name="proses">Proses</button>
						</div>
						<?php  
						if (isset($_POST["proses"])) {
							$id_pembelian = $_GET["id"];
							$masukkan = $koneksi->query("SELECT * FROM order_masuk WHERE id_order='$id_pembelian'");
							$bank = $_POST["bank"];
							$norek = $_POST["norek"];
							$tujuan = $_POST["rekening_tujuan"];
							$koneksi->query("INSERT INTO transaksi (id_rekening_tujuan,id_order,id_bank,no_rekening) VALUES ('$tujuan','$id_pembelian','$bank','$norek')");
							$koneksi->query("UPDATE order_masuk SET status='Sudah Membayar' WHERE id_order='$id_pembelian'");
							echo "<script>alert('Pembayaran Sukses');</script>";
							echo "<script>location='nota.php?id=$id_pembelian'</script>";
						}
						?>
					</form>
				</div>
			</div>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>