<?php 
include 'panel/include/header-customer.php';
include 'panel/include/tanggal_indonesia.php';
$id_produk = $_GET["id"];
$link = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
$detail = $link->fetch_assoc();
?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=""><a href="home.php">Beranda</a></li>
			<li class="active">Detail Produk</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<div class="row">
			<div class="product product-details clearfix">
				<div class="col-md-6">
					<div id="product-main-view">
						<div class="product-view">
							<img src="produk/<?php echo $detail['foto']; ?>" alt="">
						</div>
					</div>
				</div>
				<div class="col-md-6">
					<div class="product-body">
						<h2 class="product-name"><?php echo $detail['nama']; ?></h2>
						<h3 class="product-price">
						Rp. <?php echo number_format($detail['harga_baru'],0,",","."); ?><br>
						<del class="product-old-price">
						Rp. <?php echo number_format($detail['harga_lama'],0,",","."); ?></del></h3>
						<div>
							<div class="product-rating">
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star"></i>
								<i class="fa fa-star-o empty"></i>
							</div>
							<a href="">3 Ulasan</a>
						</div>
						<hr>
						<p><strong>Tersedia : </strong><?php echo $detail['stock']; ?></p>
						<br>
						<form method="post">
						<div class="product-btns">
							<a href="home.php" class="primary-btn">Kembali</a>
							<button class="main-btn primary" name="order">Masuk Keranjang</button>
							<div class="pull-right">
								<button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
								<button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button>
							</div>
						</div>
						<?php 
						if (isset($_POST["order"])) {
							$_SESSION["keranjang"][$id_produk]++;
		       				echo "<script>location='keranjang.php';</script>";
						}
						?>
						</form>
					</div>
				</div>
				<div class="col-md-12">
					<div class="product-tab">
						<ul class="tab-nav">
							<li><p><strong>Detail Produk</strong></p></li>
						</ul>
						<div class="tab-content">
							<div id="tab1">
								<p><?php echo $detail['deskripsi_produk']; ?></p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>