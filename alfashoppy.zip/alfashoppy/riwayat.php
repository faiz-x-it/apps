<?php
include 'panel/include/header-customer.php';
if (!isset($_SESSION["customer"]) OR empty($_SESSION["customer"])) {
	echo "<script>alert('Silahkan Login');</script>";
	echo "<script>location='login-customer.php';</script>";
	exit();
}
?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=""><a href="home.php">Beranda</a></li>
			<li class="active">Riwayat</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<div class="section-title"><h3>Riwayat Belanja</h3></div>
		<div class="row">
			<form method="post">
				<div class="col-md-12">
					<div class="table-responsive">
						<table class="table invoice-items table-striped table-bordered">
							<thead>
								<tr class="h5 text-dark">
									<th>No</th>
									<th>Tanggal</th>
									<th>Total</th>
									<th>Status Order</th>
									<th>Resi Pengiriman</th>
									<th>Opsi</th>
								</tr>
							</thead>
							<tbody>
							<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
							<?php 
					    	$no = 1;
					    	$id_customer = $_SESSION["customer"]["id_customer"];
						    $masukkan = $koneksi->query("SELECT * FROM order_masuk WHERE id_customer='$id_customer'");
						    while ($detail = $masukkan->fetch_assoc()) {
						    ?>
								<tr class="h5">
									<td><?php echo $no; ?></td>
									<td><?php echo $detail['tanggal']; ?></td>
									<td>Rp. <?php echo number_format($detail['grand_total'],0,",","."); ?></td>
									<?php if ($detail['status']=="Pending"): ?>
									<td><a class="btn btn-warning btn-xs"><?php echo $detail['status']; ?></a></td>
									<td></td>
									<td><a href="pembayaran.php?id=<?php echo $detail["id_order"] ?>" class="btn btn-primary btn-xs">Pembayaran</a></td>
									<?php endif ?>
									<?php if ($detail['status']=="Sudah Membayar"): ?>
									<td><a class="btn btn-success btn-xs"><?php echo $detail['status']; ?></a></td>
									<td></td>
									<td><a href="nota.php?id=<?php echo $detail["id_order"] ?>" class="btn btn-info btn-xs">Nota</a></td>
									<?php endif ?>
									<?php if ($detail['status']=="Barang Dikemas"): ?>
									<td><a class="btn btn-success btn-xs"><?php echo $detail['status']; ?></a></td>
									<td>
										<?php if (!empty($detail['kode_resi'])): ?>
										<b>Resi : <?php echo $detail['kode_resi']; ?></b>
										<?php endif ?>
									</td>
									<td><a href="nota.php?id=<?php echo $detail["id_order"] ?>" class="btn btn-info btn-xs">Nota</a></td>
									<?php endif ?>
									<?php if ($detail['status']=="Barang Sedang Dikirim"): ?>
									<td><a class="btn btn-success btn-xs"><?php echo $detail['status']; ?></a></td>
									<td>
										<?php if (!empty($detail['kode_resi'])): ?>
										<b>Resi : <?php echo $detail['kode_resi']; ?></b>
										<?php endif ?>
									</td>
									<td><a href="nota.php?id=<?php echo $detail["id_order"] ?>" class="btn btn-info btn-xs">Nota</a></td>
									<?php endif ?>
									<?php if ($detail['status']=="Barang Sudah Sampai"): ?>
									<td><a class="btn btn-success btn-xs"><?php echo $detail['status']; ?></a></td>
									<td>
										<?php if (!empty($detail['kode_resi'])): ?>
										<b>Resi : <?php echo $detail['kode_resi']; ?></b>
										<?php endif ?>
									</td>
									<td><a href="nota.php?id=<?php echo $detail["id_order"] ?>" class="btn btn-info btn-xs">Nota</a></td>
									<?php endif ?>
									<?php if ($detail['status']=="Pengiriman Ditunda"): ?>
									<td><a class="btn btn-danger btn-xs"><?php echo $detail['status']; ?></a></td>
									<td><a href="nota.php?id=<?php echo $detail["id_order"] ?>" class="btn btn-info btn-xs">Nota</a></td>
									<?php endif ?>
								</tr>
							<?php 
							$no++;
        					} 
        					?>
        					<!--  = = = = = = = = = = = = = = PHP = = = = = = = = = = = = = = -->
							</tbody>
						</table>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>