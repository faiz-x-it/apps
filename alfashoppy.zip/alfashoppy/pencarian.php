<?php
include 'panel/include/header-customer.php';
$kata_kunci = $_GET["kata_kunci"];
$hasil = array();
$masukkan = $koneksi->query("SELECT * FROM produk WHERE nama LIKE '%$kata_kunci%' OR deskripsi_produk LIKE '%$kata_kunci%' OR foto LIKE '$kata_kunci'");
while($tampil = $masukkan->fetch_assoc()) {
	$hasil[] = $tampil;
}
?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=""><a href="home.php">Beranda</a></li>
			<li class="active">Pencarian</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title">
					<h3>Hasil Pencarian : <?php echo "$kata_kunci"; ?></h3>
					<?php 
					if (empty($hasil)):
						echo "<script>alert('Produk Tidak Ditemukan');</script>";
						echo "<script>location='home.php';</script>"; 
					endif
					?>
				</div>
			</div>
			<?php foreach ($hasil as $key => $nilai): ?>
			<div class="col-md-3">
				<div class="product product-single">
					<div class="product-thumb">
						<img src="produk/<?php echo $nilai['foto']; ?>" height="210" alt="">
					</div>
					<div class="product-body">
						<i><h2 class="product-name"><a href="#"><?php echo $nilai['nama']; ?></a></h2></i>
						<h3 class="product-price"><small>
						<i>Rp. <?php echo number_format($nilai['harga_baru'],0,",","."); ?></i>
						</small><del class="product-old-price"><br>
						<i>Rp. <?php echo number_format($nilai['harga_lama'],0,",","."); ?></i></del></h3>
						<div class="product-rating">
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star-o empty"></i>
						</div>
						<div class="product-btns">
							<button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
							<button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button>
							<a href="detail-produk.php?id=<?php echo $nilai["id_produk"]; ?>"><button class="primary-btn pull-right add-to-cart"><small>Order Produk</small></button></a>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach ?>
		</div>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>