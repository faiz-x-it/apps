<?php 
include 'panel/include/header-customer.php';
?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=""><a href="home.php">Beranda</a></li>
			<li class="active">Login Customer</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<div class="row">
			<form id="checkout-form" class="clearfix" method="post">
				<div class="col-md-4"> 
					<div class="billing-details">
						<div class="form-group">
							<input class="input" type="text" name="email" placeholder="Email" required>
						</div>
						<div class="form-group">
							<input class="input" type="password" name="password" placeholder="Password" required>
						</div>
					</div>
					<div class="form-group">
						<div class="text-left">
							<button class="primary-btn btn-block" name="login">Login</button>
						</div>
					</div>
					<p>Belum Punya Akun ?,<b><a href="daftar-akun.php"> Klik Disini</a></b></p>
				</div>
				<?php
				if (isset($_POST['login'])) {
					$email = $_POST["email"];
					$password = md5($_POST["password"]);
					$masukkan = $koneksi->query("SELECT * FROM customer WHERE email_login='$email' AND password='$password'");
					$akun_benar = $masukkan->num_rows;
					if ($akun_benar==1) {
					$akun = $masukkan->fetch_assoc();
					$_SESSION["customer"] = $akun;
					echo "<script>alert('Berhasil Login');</script>";
    				echo "<script>location='home.php';</script>";
					} else {
						echo "<script>alert('Login Gagal');</script>";
                        echo "<script>location='login-customer.php';</script>";
					}
				}
				?>
 			</form>
		</div>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>