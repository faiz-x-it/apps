<?php include 'panel/koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Alfashoppy</title>
	<?php include 'panel/include/bootstrap.php'; ?>
</head>
<body>
	<nav class="navbar navbar-default">
		<div class="container">
			<ul class="nav navbar-nav">
				<li><a href="index.php">Home</a></li>
				<li><a href="kerajang.php">Keranjang</a></li>
				<li><a href="login.php">Login</a></li>
				<li><a href="checkout.php">Checkout</a></li>
			</ul>
		</div>
	</nav>
	<section class="content">
		<div class="container">
			<h3>Daftar Produk</h3>
			<div class="row">
				<?php $ambil = $koneksi->query("SELECT * FROM produk"); ?>
				<?php while($data = $ambil->fetch_assoc()) { ?>
				<div class="col-md-3">
					<div class="thumbnail">
						<img class="img-responsive zoom" src="produk/<?php echo ($data['foto']); ?>" alt="" style="width: 100%; height: 220px;">
						<div class="caption">
							<h4><?php echo ($data['nama']); ?></h4>
							<h5><b>Rp. <?php echo number_format ($data['harga_baru'],0,",","."); ?></b></h5>
							<h6><s>Rp. <?php echo number_format ($data['harga_lama'],0,",","."); ?></s></h6>
							<hr>
							<a href="" class="btn btn-sm btn-success">Lihat Detail</a>
							<a href="" class="btn btn-sm btn-primary">Beli</a>
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
		</div>
	</section>
<?php include 'panel/include/bootstrap.php'; ?>
</body>
</html>