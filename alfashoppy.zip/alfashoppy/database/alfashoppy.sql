-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 12 Nov 2021 pada 16.42
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alfashoppy`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `administrator`
--

CREATE TABLE `administrator` (
  `id_administrator` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `administrator`
--

INSERT INTO `administrator` (`id_administrator`, `nama`, `username`, `password`) VALUES
(1, 'Muhammad Itbaul Walidaini', 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bank`
--

CREATE TABLE `bank` (
  `id_bank` int(11) NOT NULL,
  `nama` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `bank`
--

INSERT INTO `bank` (`id_bank`, `nama`) VALUES
(1, 'Bank Mandiri'),
(2, 'Bank BRI'),
(3, 'Bank BNI'),
(4, 'Bank Jatim'),
(5, 'Bank BCA');

-- --------------------------------------------------------

--
-- Struktur dari tabel `customer`
--

CREATE TABLE `customer` (
  `id_customer` int(11) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `alamat_customer` varchar(255) NOT NULL,
  `no_telepon` varchar(255) NOT NULL,
  `email_login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `customer`
--

INSERT INTO `customer` (`id_customer`, `nama_lengkap`, `alamat_customer`, `no_telepon`, `email_login`, `password`) VALUES
(1, 'Muhammad Itbaul Walidaini', 'Kamulan', '083845724228', 'itbaul@gmail.com', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_order`
--

CREATE TABLE `detail_order` (
  `id_detail_order` int(11) NOT NULL,
  `id_order` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `total_berat` varchar(100) NOT NULL,
  `total_harga` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `detail_order`
--

INSERT INTO `detail_order` (`id_detail_order`, `id_order`, `id_produk`, `qty`, `total_berat`, `total_harga`) VALUES
(1, 1, 2, 2, '400', '4200000'),
(2, 1, 3, 1, '1500', '15500000'),
(3, 1, 5, 2, '800', '6000000');

--
-- Trigger `detail_order`
--
DELIMITER $$
CREATE TRIGGER `pembelian_produk` AFTER INSERT ON `detail_order` FOR EACH ROW BEGIN UPDATE produk SET stock=stock-NEW.qty
WHERE id_produk = NEW.id_produk;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `jasa_pengiriman`
--

CREATE TABLE `jasa_pengiriman` (
  `id_jasa_pengiriman` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `jasa_pengiriman`
--

INSERT INTO `jasa_pengiriman` (`id_jasa_pengiriman`, `nama`) VALUES
(1, 'JNE'),
(2, 'JNT'),
(3, 'Antareja'),
(4, 'TIKI'),
(5, 'SiCepat Express');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Motherboard'),
(2, 'Processor'),
(3, 'Penyimpanan'),
(4, 'Peripheral'),
(5, 'RAM'),
(6, 'Kartu Grafis');

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_masuk`
--

CREATE TABLE `order_masuk` (
  `id_order` int(11) NOT NULL,
  `id_customer` int(11) NOT NULL,
  `id_tarif_ongkir` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `alamat` text NOT NULL,
  `sub_total` varchar(100) NOT NULL,
  `grand_total` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `kode_resi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `order_masuk`
--

INSERT INTO `order_masuk` (`id_order`, `id_customer`, `id_tarif_ongkir`, `tanggal`, `alamat`, `sub_total`, `grand_total`, `status`, `kode_resi`) VALUES
(1, 1, 2, '2021-11-12', 'Kamulan RT21/RW04', '25700000', '25715000', 'Barang Dikemas', '123AAC');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `harga_lama` varchar(255) NOT NULL,
  `harga_baru` varchar(255) NOT NULL,
  `berat` decimal(10,0) NOT NULL,
  `stock` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `deskripsi_produk` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `id_kategori`, `nama`, `harga_lama`, `harga_baru`, `berat`, `stock`, `foto`, `deskripsi_produk`) VALUES
(1, 2, 'AMD Ryzen 5 3500', '5000000', '5200000', '200', '11', 'Ryzen 5 3500.jpg', '<p>Okey</p>\r\n'),
(2, 1, 'Aorus B360', '2000000', '2100000', '200', '7', 'Aorus B360.jpeg', '<p>Motherboard Oke</p>\r\n'),
(3, 6, 'Aorus XTreme 2060 OC', '15000000', '15500000', '1500', '5', 'Aorus XTreme 2060.png', '<p>GPU Mantul</p>\r\n'),
(4, 5, 'TForce DeltaR (8x2GB)', '2200000', '2500000', '300', '8', 'TForce Delta R.jpg', '<p>RAM Ngebut</p>\r\n'),
(5, 5, 'HyperX Fury (8x2GB)', '2800000', '3000000', '400', '8', 'Ram HyperX Fury.jpg', '<p>Oke</p>\r\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekening_tujuan`
--

CREATE TABLE `rekening_tujuan` (
  `id_rekening_tujuan` int(11) NOT NULL,
  `id_bank` int(11) NOT NULL,
  `pemilik` varchar(50) NOT NULL,
  `no_rekening` varchar(50) NOT NULL,
  `cabang` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `rekening_tujuan`
--

INSERT INTO `rekening_tujuan` (`id_rekening_tujuan`, `id_bank`, `pemilik`, `no_rekening`, `cabang`) VALUES
(1, 1, 'Muhammad Itbaul Walidaini', '09340953', 'Trenggalek'),
(2, 2, 'Novia Nur Saidah', '0900970955', 'Blitar'),
(3, 2, 'Shely Oktavianita', '234234234', 'Durenan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tarif_ongkir`
--

CREATE TABLE `tarif_ongkir` (
  `id_tarif_ongkir` int(11) NOT NULL,
  `id_jasa_pengiriman` int(11) NOT NULL,
  `tarif` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tarif_ongkir`
--

INSERT INTO `tarif_ongkir` (`id_tarif_ongkir`, `id_jasa_pengiriman`, `tarif`) VALUES
(1, 2, '50000'),
(2, 1, '15000'),
(3, 4, '10000'),
(4, 3, '20000');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `id_rekening_tujuan` int(11) NOT NULL,
  `id_order` int(11) NOT NULL,
  `id_bank` int(11) NOT NULL,
  `no_rekening` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `id_rekening_tujuan`, `id_order`, `id_bank`, `no_rekening`) VALUES
(1, 1, 1, 1, '234234234234');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`id_administrator`);

--
-- Indeks untuk tabel `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`id_bank`);

--
-- Indeks untuk tabel `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id_customer`);

--
-- Indeks untuk tabel `detail_order`
--
ALTER TABLE `detail_order`
  ADD PRIMARY KEY (`id_detail_order`);

--
-- Indeks untuk tabel `jasa_pengiriman`
--
ALTER TABLE `jasa_pengiriman`
  ADD PRIMARY KEY (`id_jasa_pengiriman`);

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `order_masuk`
--
ALTER TABLE `order_masuk`
  ADD PRIMARY KEY (`id_order`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indeks untuk tabel `rekening_tujuan`
--
ALTER TABLE `rekening_tujuan`
  ADD PRIMARY KEY (`id_rekening_tujuan`);

--
-- Indeks untuk tabel `tarif_ongkir`
--
ALTER TABLE `tarif_ongkir`
  ADD PRIMARY KEY (`id_tarif_ongkir`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `administrator`
--
ALTER TABLE `administrator`
  MODIFY `id_administrator` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `bank`
--
ALTER TABLE `bank`
  MODIFY `id_bank` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `customer`
--
ALTER TABLE `customer`
  MODIFY `id_customer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `detail_order`
--
ALTER TABLE `detail_order`
  MODIFY `id_detail_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `jasa_pengiriman`
--
ALTER TABLE `jasa_pengiriman`
  MODIFY `id_jasa_pengiriman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `order_masuk`
--
ALTER TABLE `order_masuk`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `rekening_tujuan`
--
ALTER TABLE `rekening_tujuan`
  MODIFY `id_rekening_tujuan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tarif_ongkir`
--
ALTER TABLE `tarif_ongkir`
  MODIFY `id_tarif_ongkir` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
