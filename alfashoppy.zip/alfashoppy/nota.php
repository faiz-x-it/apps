<?php 
include 'panel/include/header-customer.php';
$masukkan = $koneksi->query("SELECT * FROM order_masuk LEFT JOIN customer ON order_masuk.id_customer=customer.id_customer WHERE order_masuk.id_order='$_GET[id]'");
$detail = $masukkan->fetch_assoc();
$id_customer = $detail["id_customer"];
$id_customer_login = $_SESSION["customer"]["id_customer"];
if ($id_customer!==$id_customer_login) {
	echo "<script>location='riwayat.php';</script>";
	exit();
}
?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=""><a href="home.php">Beranda</a></li>
			<li class="active">Nota</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="order-summary clearfix">
					<header class="clearfix">
						<div class="row">
							<div class="col-md-6 text-left">
								<div class="ib">
									<img src="img/logo-nota.png" alt="">
								</div>
							</div>
							<div class="col-md-6 text-right">
								<address class="ib mr-xlg">
									Email : alfashoppy.indonesia@gmail.com<br>
									Telepon : 083 845 724 228<br>
									Alamat : Jl.Raya Kamulan, Kec.Durenan, Kab.Trenggalek, Jawa Timur<br>
								</address>
							</div>
						</div>
					</header>
					<p><h4>Rincian Pembelian</h4></p>
					<div class="table-responsive">
						<table class="table invoice-items table-bordered table-striped">
							<thead>
								<tr class="h5 text-dark">
									<th>No</th>
									<th>Produk</th>
									<th>Berat (gr)</th>
									<th>Harga (Rp)</th>
									<th>Jumlah</th>
									<th>Sub Berat</th>
									<th>Sub Harga</th>
								</tr>
							</thead>
							<tbody>
							<?php 
							$no = 1;
							$masukkan = $koneksi->query("SELECT * FROM detail_order JOIN produk ON detail_order.id_produk=produk.id_produk WHERE id_order ='$_GET[id]'");
							while ($tampil = $masukkan->fetch_assoc()) { 
							?>
							<tr class="h5 text-dark">
								<td><?php echo $no; ?></td>
								<td><?php echo $tampil['nama']; ?></td>
								<td><?php echo $tampil['berat']; ?> gr</td>
								<td>Rp. <?php echo number_format($tampil['harga_baru'],0,",","."); ?></td>
								<td><?php echo $tampil['qty']; ?></td>
								<td><?php echo number_format($tampil['total_berat'],0,",","."); ?> gr</td>
								<td>Rp. <?php echo number_format($tampil['total_harga'],0,",","."); ?></td>
							</tr>
							<?php 
							$no++;
							} 
							?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="col-md-12">
				<div class="row">
					<div class="col-xs-5 pull-left">
                		<p>
                			<h4>Informasi Penerima</h4>
                			Kode Pembelian : SPFY-3X00<?php echo $detail['id_order'] ?><br>
                			Tanggal :</b> <?php echo $detail['tanggal'] ?><br>
                			Nama : <?php echo $detail['nama_lengkap'] ?><br>
                			Email : <?php echo $detail['email_login'] ?><br>
                			Alamat : <?php echo $detail['alamat'] ?><br>
                			No Telepon : <?php echo $detail['no_telepon'] ?>
                		</p>
                	</div>
                	<div class="col-xs-5 pull-right">
                		<p><h4>Rincian Pembayaran</h4></p>
                		<div class="table-responsive">
                			<table class="table invoice-items table-striped table-bordered">
                				<tbody>
                					<tr class="h5 text-dark">
                						<th>Sub Total</th>
                						<td>Rp. <?php echo number_format($detail['sub_total'],0,",","."); ?></td>
                					</tr>
                					<tr class="h5 text-dark">
                						<th>Tarif Ongkir</th>
                						<?php
                                        $masukkan = $koneksi->query("SELECT * FROM order_masuk LEFT JOIN tarif_ongkir 
                                        ON order_masuk.id_tarif_ongkir=tarif_ongkir.id_tarif_ongkir");
                                        while ($okr = $masukkan->fetch_assoc()) { 
                                        ?>
                						<td>Rp. <?php echo number_format($okr['tarif'],0,",","."); ?></td>
                						<?php } ?>
                					</tr>
                					<tr class="h5 text-dark">
                						<th>Grand Total</th>
                						<td>Rp. <?php echo number_format($detail['grand_total'],0,",","."); ?></td>
                					</tr>
                				</tbody>
                			</table>
                		</div>
                	</div>
                	<div class="col-sm-12">
                        <a href="riwayat.php" class="btn btn-primary">Terima</a>
                    </div>
            	</div>
        	</div>
		</div>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>