<?php include 'panel/include/header-customer.php'; ?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=""><a href="home.php">Beranda</a></li>
			<li class="active">Daftar Akun</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<div class="row">
			<form id="checkout-form" class="clearfix" method="post">
				<div class="col-md-4"> 
					<div class="billing-details">
						<div class="form-group">
							<input class="input" type="text" name="nama_lengkap" placeholder="Nama Lengkap" required>
						</div>
						<div class="form-group">
							<input class="input" type="text" name="alamat" placeholder="Alamat" required>
						</div>
						<div class="form-group">
							<input class="input" type="number" min="0" name="no_telepon" placeholder="No Telepon" required>
						</div>
						<div class="form-group">
							<input class="input" type="text" name="email" placeholder="Email" required>
						</div>
						<div class="form-group">
							<input class="input" type="password" name="password" placeholder="Password (maksimal 6 karakter)" maxlength="6" required>
						</div>	
					</div>
					<div class="form-group">
						<div class="text-left">
							<button class="primary-btn btn-block" name="daftar">Daftar</button>
						</div>
					</div>
					<p>Sudah Punya Akun ?,<b><a href="login-customer.php"> Login</a></b></p>
				</div>
				<?php
				if (isset($_POST["daftar"])) {
			 		$nama_lengkap = $_POST["nama_lengkap"];
					$alamat = $_POST["alamat"];
					$no_telepon = $_POST["no_telepon"];
					$email = $_POST["email"];
					$password = md5($_POST["password"]);
					$masukkan = $koneksi->query("SELECT * FROM customer WHERE email_login='$email'");
					$email_yang_cocok = $masukkan->num_rows;
					if ($email_yang_cocok==1) {
						echo "<script>alert('Email Sudah Digunakan');</script>";
						echo "<script>location='daftar-customer.php';</script>";
					} else {
						$koneksi->query("INSERT INTO customer (nama_lengkap,alamat_customer,no_telepon,email_login,password) 
						VALUES ('$nama_lengkap','$alamat','$no_telepon','$email','$password')");
						echo "<script>alert('Akun Berhasil Dibuat');</script>";
						echo "<meta http-equiv='refresh' content='1;url=login-customer.php'>";	
					}
				}
				?>
			</form>
		</div>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>