<div class="row">
	<div class="col-md-12">
		<div class="section-title">
			<h3>Diskon Hari Ini</h3>
			<div class="pull-right">
				
			</div>
		</div>
	</div>
	<div class="col-md-3 col-sm-6 col-xs-6">
		<div class="banner banner-2">
			<img src="./img/bnr.jpg" alt="">
			<div class="banner-caption">
				<h2 class="white-color">Produk Terbaru</h2>
				<button class="primary-btn"><small>Beli Sekarang</small></button>
			</div>
		</div>
	</div>
	<div class="col-md-9 col-sm-6 col-xs-6">
		<div class="row">
			<div id="product-slick-1" class="product-slick">
				<?php
				$sql = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY id_produk DESC");
				if(mysqli_num_rows($sql) == 0) {
					echo "Produk Tidak Tersedia";
				}else {
				while($data = mysqli_fetch_assoc($sql)) { 
				?>
				<div class="product product-single">
					<div class="product-thumb">
						<img src="produk/<?php echo $data['foto']; ?>" height="210" alt="">
					</div>
					<div class="product-body">
						<i><h2 class="product-name"><a href="#"><?php echo $data['nama']; ?></a></h2></i>
						<h3 class="product-price"><small>
						<i>Rp. <?php echo number_format($data['harga_baru'],0,",",".");?></i>
						</small><del class="product-old-price"><br>
						<i>Rp. <?php echo number_format($data['harga_lama'],0,",",".");?></i></del></h3>
						<div class="product-rating">
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star"></i>
							<i class="fa fa-star-o empty"></i>
						</div>
						<div class="product-btns">
							<button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
							<button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button>
							<a href="detail-produk.php?id=<?php echo $data["id_produk"]; ?>"><button class="primary-btn add-to-cart"><i class="fa fa-download"></i> <small> Order</small></button></a>
						</div>
					</div>
				</div>
				<?php   
				}
				}
				?>
			</div>
		</div>
	</div>
</div>