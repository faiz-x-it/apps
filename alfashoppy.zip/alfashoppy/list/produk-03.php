<div class="row">
	<div class="col-md-12">
		<div class="section-title">
			<h3>Semua Produk</h3>
		</div>
	</div>
	<?php
	$per_halaman = 4;
	$halaman = isset($_GET["halaman"]) ? (int)$_GET["halaman"] : 1;
	$mulai = ($halaman > 1) ? ($halaman * $per_halaman) - $per_halaman : 0;
	$isi = "SELECT * FROM produk LIMIT $mulai, $per_halaman";
	$result2 = mysqli_query($koneksi, $isi);
	$result = mysqli_query($koneksi, "SELECT * FROM produk");
	$total = mysqli_num_rows($result);
	$jumlah_halaman = ceil($total/$per_halaman);
	$sql = mysqli_query($koneksi, "SELECT * FROM produk ORDER BY id_produk DESC");
	if (mysqli_num_rows($sql) == 0) {
		echo "<div class='col-sm-6'>Produk Belum Tersedia</div>";
	}else {
	while($data = mysqli_fetch_assoc($result2)) { 
	?>
	<div class="col-md-3 col-sm-6 col-xs-6">
		<div class="product product-single">
			<div class="product-thumb">
				<img src="produk/<?php echo $data['foto']; ?>" height="210" alt="">
			</div>
			<div class="product-body">
				<i><h2 class="product-name"><?php echo $data['nama']; ?></h2></i>
				<h3 class="product-price"><small>
				<i><b>Rp. <?php echo number_format($data['harga_baru'],0,",","."); ?></b></i>
				</small><del class="product-old-price"><br>
				<i>Rp. <?php echo number_format($data['harga_lama'],0,",","."); ?></i></del></h3>
				<div class="product-rating">
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star"></i>
					<i class="fa fa-star-o empty"></i>
					<i class="fa fa-star-o empty"></i>
				</div>
				<div class="product-btns">
					<button class="main-btn icon-btn"><i class="fa fa-heart"></i></button>
					<button class="main-btn icon-btn"><i class="fa fa-exchange"></i></button>
					<a href="detail-produk.php?id=<?php echo $data["id_produk"]; ?>"><button class="primary-btn pull-right add-to-cart"><small>Detail Produk</small></button></a>
				</div>
			</div>
		</div>	
	</div>
	<?php   
	}
	}
	?>
</div>
<div class="pull-right">
	<div class="page-filter">
		<ul class="store-pages btn btn-default">Halaman :
			<?php for($i =1; $i <=$jumlah_halaman; $i++) { ?>
				<li><a href="?produk&halaman=<?php echo $i ?>"><b><?php echo $i ?></b></a></li>
			<?php } ?>
		</ul>	
	</div>
</div>