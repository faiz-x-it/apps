<?php  
session_start();
$id_produk=$_GET["id"];
if(isset($_SESSION["keranjang"][$id_produk])) {
	$_SESSION['keranjang'][$id_produk]--;
	if($_SESSION['keranjang'][$id_produk]==0)
	unset($_SESSION["keranjang"][$id_produk]);
}
echo "<script>location='keranjang.php';</script>";
?>