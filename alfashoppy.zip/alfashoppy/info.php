<?php
include 'panel/include/header-customer.php';
$masukkan = $koneksi->query("SELECT * FROM order_masuk LEFT JOIN customer ON order_masuk.id_customer=customer.id_customer WHERE order_masuk.id_order='$_GET[id]'");
$detail = $masukkan->fetch_assoc();
$id_customer = $detail["id_customer"];
$id_customer_login = $_SESSION["customer"]["id_customer"];
if ($id_customer!==$id_customer_login) {
	echo "<script>location='riwayat.php';</script>";
	exit();
}
?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=""><a href="home.php">Beranda</a></li>
			<li class="active">Info</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<h2>Yeeyyy..! :)</h2>
		<font size="3">
		<p>
		Terimakasih telah melakukan pembelian produk di toko kami, semoga barangnya berkah dan bermanfaat. percayakan semua kebutuhan anda hanya di Alfashoppy.
		<br> 
		Untuk Melihat status order barang, lihat pada riwayat anda.
		<br>
		<hr>
		Kode Pembelian : <b>SPFY-3X00<?php echo $detail['id_order'] ?></b><br>
		Atas Nama : <b><?php echo $detail['nama_lengkap'] ?></b><br>
		Email : <b><?php echo $detail['email_login'] ?></b><br>
		Total Tagihan Anda : <b>Rp. <?php echo number_format($detail['grand_total'],0,",","."); ?></b><br>
		Alamat Pengiriman : <?php echo $detail['alamat']; ?>
		</p>
		</font>
		<hr>
			<div class="row">
				<div class="pull-left col-md-6">
					<a href="riwayat.php" class="main-btn">Ok, Saya Terima</a>
				</div>
			</div>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>