<?php 
include 'panel/include/header-customer.php';
if (!isset($_SESSION["customer"])) {
	echo "<script>alert('Silahkan Login Terlebih Dahulu');</script>";
    echo "<script>location='login-customer.php';</script>";
} elseif (empty($_SESSION["keranjang"])) {
	echo "<script>alert('Keranjang Anda Kosong');</script>";
    echo "<script>location='home.php';</script>";
}
?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=" "><a href="home.php">Beranda</a></li>
			<li class="active">Checkout</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<div class="section-title"><h3>Checkout</h3></div>
		<div class="row">	
			<div class="col-md-12">
				<div class="order-summary clearfix table-responsive">
					<table class="table invoice-items table-bordered table-striped">
						<thead>
							<tr class="h5 text-dark">
								<th>No</th>
								<th>Produk</th>
								<th>Berat</th>
								<th>Harga</th>
								<th>Qty</th>
								<th>Sub Berat</th>
								<th>Sub Harga</th>
							</tr>
						</thead>
						<tbody>
						<?php 
						$nomor = 1; 
						$sub_berat = 0;
						$sub_total = 0;
						foreach ($_SESSION["keranjang"] as $id_produk => $jumlah):
						$masukkan = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
						$detail = $masukkan->fetch_assoc();
						$t_berat = $detail["berat"]*$jumlah;
						$t_harga = $detail["harga_baru"]*$jumlah;
						?>
							<tr class="h5">
								<td><?php echo $nomor; ?></td>
								<td><?php echo $detail["nama"]; ?></td>
								<td><?php echo number_format($detail['berat'],0,",","."); ?> gr</td>
								<td>Rp. <?php echo number_format($detail['harga_baru'],0,",","."); ?></td>
								<td><?php echo $jumlah; ?></td>
								<td><?php echo $t_berat; ?> gram</td>
								<td>Rp. <?php echo number_format($t_harga,0,",","."); ?></td>
							</tr>
						<?php 
						$nomor++;
						$sub_berat+=$t_berat;
						$sub_total+=$t_harga; 
						endforeach
						?>
						</tbody>
						<tfoot>
							<tr>
								<th colspan="5">Grand Total</th>
								<th><?php echo number_format($sub_berat,0,",","."); ?> gram</th>
								<th>Rp. <?php echo number_format($sub_total,0,",","."); ?></th>
							</tr>
						</tfoot>
					</table>
				</div>
				<form method="post" id="checkout-form" class="clearfix">
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<input type="text" readonly value="<?php echo $_SESSION["customer"]['nama_lengkap']?>" class="input">
							</div>
						</div>
						<div class="col-md-3">
							<div class="form-group">
								<input type="text" readonly value="<?php echo $_SESSION["customer"]['no_telepon']?>" class="input">
							</div>
						</div>
						<div class="col-md-6">
							<div class="form-group">
								<select class="input" name="tarif" required>
									<option value="">Pilih Jasa Kirim</option>
									<?php
									$masukkan = $koneksi->query("SELECT * FROM tarif_ongkir LEFT JOIN jasa_pengiriman 
									ON tarif_ongkir.id_jasa_pengiriman=jasa_pengiriman.id_jasa_pengiriman");
									while ($per_ongkir = $masukkan->fetch_assoc()) { 
									?>
									<option value="<?php echo $per_ongkir["id_tarif_ongkir"] ?>"><?php echo $per_ongkir['nama'] ?> -
									Rp. <?php echo number_format($per_ongkir['tarif'],0,",","."); ?>
									</option>
									<?php 
									}
									?>
								</select>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12">
							<div class="review-form">
								<textarea class="input" name="alamat" placeholder="Tulis alamat anda dengan detail" required></textarea>
							</div>
						</div>
					</div>
					<div class=""><h3></h3></div>
					<div class="text-left">
						<a href="keranjang.php" class="primary-btn">Kembali</a>
						<button class="main-btn" name="order">Order Now</button>
					</div>
					<?php
					if (isset($_POST["order"])) {
					$id_customer = $_SESSION["customer"]['id_customer'];
					$id_tarif_ongkir = $_POST["tarif"];
					$tanggal_order = date('Y-m-d');
					$alamat = $_POST["alamat"];
					$masukkan = $koneksi->query("SELECT * FROM tarif_ongkir LEFT JOIN jasa_pengiriman 
					ON tarif_ongkir.id_jasa_pengiriman=jasa_pengiriman.id_jasa_pengiriman WHERE id_tarif_ongkir='$id_tarif_ongkir'");
					$arraytarif = $masukkan->fetch_assoc();
					$tarif = $arraytarif['tarif'];
					$grand_total = $sub_total+$tarif;
					$koneksi->query("INSERT INTO order_masuk (id_customer,id_tarif_ongkir,tanggal,alamat,sub_total,grand_total) VALUES
					('$id_customer','$id_tarif_ongkir','$tanggal_order','$alamat','$sub_total','$grand_total')");

					//-----------------------------------------------------------//

					$id_beli = $koneksi->insert_id;
					foreach ($_SESSION["keranjang"] as $id_produk => $qty) {
						$masukkan = $koneksi->query("SELECT * FROM produk WHERE id_produk='$id_produk'");
						$perproduk = $masukkan->fetch_assoc();
						$total_berat = $perproduk['berat']*$qty;
						$total_harga = $perproduk['harga_baru']*$qty;
						$koneksi->query("INSERT INTO detail_order (id_order,id_produk,qty,total_berat,total_harga) VALUES
						('$id_beli','$id_produk','$qty','$total_berat','$total_harga')");
					}
					$koneksi->query("UPDATE order_masuk SET status='Pending' WHERE id_order='$id_beli'");
					unset($_SESSION["keranjang"]);
					echo "<script>alert('Order Berhasil');</script>";
					echo "<script>location='info.php?id=$id_beli'</script>";
				}
				?>
				</form>
			</div>
		</div>
	</div>
</div>
<?php 
include 'panel/include/footer-customer.php';
include 'js/relod.min.js';
?>