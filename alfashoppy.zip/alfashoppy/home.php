<?php
include 'panel/include/header-customer.php';
?>
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class="active">Beranda</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
   <!-- <?php include 'list/produk-01.php'; ?>
		<?php include 'list/banner.php'; ?>
		<?php include 'list/produk-02.php'; ?> -->
		<?php include 'list/produk-03.php'; ?>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>