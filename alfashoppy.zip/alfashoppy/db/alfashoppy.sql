-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Okt 2021 pada 03.51
-- Versi server: 10.4.21-MariaDB
-- Versi PHP: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alfashoppy`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Processor'),
(2, 'Kartu Grafis'),
(3, 'Accessories'),
(4, 'RAM'),
(5, 'Motherboard');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `id_kategori` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `harga_lama` varchar(255) NOT NULL,
  `harga_baru` varchar(255) NOT NULL,
  `stock` varchar(255) NOT NULL,
  `foto` varchar(255) NOT NULL,
  `diskripsi` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `id_kategori`, `nama`, `harga_lama`, `harga_baru`, `stock`, `foto`, `diskripsi`) VALUES
(1, 1, 'AMD Ryzen 7', '6700000', '6600000', '10', 'Ryzen 7.jpg', 'Processor Oke'),
(2, 5, 'Motherboard Aorus B360', '2000000', '2200000', '8', 'Aorus B360.jpeg', 'Oke'),
(3, 2, 'Aorus XTreme 2060 OC', '15000000', '15200000', '4', 'Aorus XTreme 2060.png', 'Mantap'),
(4, 4, 'TForce DeltaR (8x2GB)', '2500000', '2750000', '23', 'TForce Delta R.jpg', 'Okey'),
(5, 4, 'HyperX Fury (8x2GB)', '2650000', '2800000', '22', 'Ram HyperX Fury.jfif', 'Okey'),
(7, 2, 'Zotac Trinity 3090', '25700000', '25900000', '21', 'Zotac Trinity 3090.jpg', 'Mantul'),
(8, 1, 'Intel i7 Gen 11700F', '6500000', '6600000', '26', 'Core i7 11700F.jpg', 'Pas'),
(9, 3, 'Aerocool Fan', '55000', '60000', '40', 'Aerocool.jpg', 'Dingin'),
(10, 3, 'Armaggeddon Fan', '60000', '70000', '50', 'Armagedoon.jpg', 'Dingin Borrr');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
