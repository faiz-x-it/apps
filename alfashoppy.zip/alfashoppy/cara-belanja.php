<?php include 'panel/include/header-customer.php'; ?>
<!-- ======================================================================================== -->
<!-- ====================================== Breadcumb. ====================================== -->
<div id="breadcrumb">
	<div class="container">
		<ul class="breadcrumb">
			<li class=""><a href="home.php">Beranda</a></li>
			<li class="active">Cara Belanja</li>
		</ul>
	</div>
</div>
<div class="section">
	<div class="container">
		<h4>Alfashoppy, belanja aman, mudah, & terpercaya</h4>
		<p>
			Selamat datang di Alfashoppy. Jangan khawatir, pelanggan akan dilayani dengan <i>fast response</i>, dan tentunya kami 100% menjamin keamanan pengiriman paket sampai tujuan.<br>
			Untuk info lebih lanjut, hubungi <i class="fa fa-whatsapp"></i> <a href="https://wa.me/6283845724228?text=Saya%20ingin%20bertanya" target="_blank">klik disini</a><br><br>
			<b>Bagaimana cara saya belanja di Alfashoppy ? </b><br><hr>
			<ol type="1">
				<li>- Mulai belanja anda dengan login akun terlebih. Belum punya akun ? klik <a href="daftar-akun.php">DISINI</a></li>
				<li>- Ingin memulai beli produk ?, pilih gambar produk lalu pilih ORDER PRODUK</li>
				<li>- Selesai melihat rincian produk, pilih MASUK KERANJANG</li>
				<li>- Pilih tombol untuk menambah, mengurangi, atau mengosongkan keranjang belanja. Selesai dengan produk yang ingin di order, pilih CHECKOUT</li>
				<li>- Isikan data order dengan benar, lalu pilih ORDER NOW</li>
				<li>- Isikan data pembayaran anda dengan benar</li>
				<li>- Selesai, lihat nota pembelian di riwayat anda<li>
				<li></li>
			</ol>
			<hr>
			<br>
		</p>
	</div>
</div>
<?php include 'panel/include/footer-customer.php'; ?>